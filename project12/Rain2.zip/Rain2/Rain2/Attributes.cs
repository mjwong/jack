using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Collections;
using System.Diagnostics;

namespace rain2
{
    public partial class Form1
    {
        private OpenFileDialog openFileDialog   = null;

        /* NN parameters */
        private double learningRate = 0.3;     // learning rate
        private double momentum     = 0.3;     // momentum factor
        private double Alpha        = 2.0;     // sigmoid constant
        private double Beta         = 0.5;     // Context layer scaling factor 0..1
        private double alphacoeff   = 0.3;     // coeff. of exponential moving average
        private double rangeSF      = 1.0;     // default to 1.0 or 100% of normalized range.
        private int    delta        = 3;       // no. of input delay elements, i.e. time steps
        private int    epsilon      = 3;       // no. of output feedback delay elements
        private int    hidActF      = 0;       // hidden layer activation function, default sigmoid
        private int    hid2ActF     = 0;       // 2nd hidden layer activation function, default sigmoid
        private int    outActF      = 0;       // output layer activation function, default sigmoid
        private int    inNodes      = 0;       // no. of input nodes
        private int    hiddenNodes  = 0;       // no. of hidden nodes
        private int    hiddenNodes2 = 0;       // no. of hidden nodes in 2nd hidden layer
        private int    outNodes     = 0;       // no. of output nodes
        
        /* data record parameters*/
        private int    firstRec     = 0;       // first row of record after the header row (row #0)
        private int    attrCnt      = 0;       // no. of attributes
        private int    readCnt      = 0;       // no. of records read
        private int    inCol        = 0;       // input column number in data file
        private int    actualStart  = 0;       // actual start of training row
        private int    trainSetStart= 0;       // first row of training set in data file (array index start from zero)
        private int    trainSetEnd  = 0;       // last row of training set in data file
        private int    testSetStart = 0;       // first row of test set in data file
        private int    testSetEnd   = 0;       // last row of test set in data file
        private int    trainCnt     = 0;       // no. of training samples
        private int    testCnt      = 0;       // no. of test samples
        private int    outColStart  = 0;       // starting output column number
        private int    outColEnd    = 0;       // ending output column number

        /* Running parameters*/
        private double minErr       = 999;      // min. error
        //private double minTestErr   = 999;      // min. test error
        private double minTestRMSE  = 999;      // min. test root-mean-sq-error
        private double errLimit     = 0.0001;   // training is stopped when this error limit is reached
        private int frequency       = 500;      // plot update frequency in mini sec
        private int iterations      = 1000;     // no. of training epochs
        private int trainTime       = 1;        // training time in minutes
        private int epochAftMinRMSE = 0;        // no. of epochs after min. test error
        private int epochFrMin      = 1000;     // no. of epochs since minimum error
        private int epochFrMinRMSE  = 1000;     // no. of epochs since minimum RMSE
        private int maxRec          = 10000;    // max. no. of records
        private int currEpoch       = 0;        // current epoch
        private double currTrnErr   = 0;        // current training error
        private double currTestErr  = 0;        // current test error
        private double smape        = 0;        // symmetric mean absolute percentage error

        /* Simulated Annealing parameters */
        private int startTemp       = 100;      // start temperature for simulated annealing
        private int finalTemp       = 1;        // final temperature for simulated annealing
        private double currTemp     = 0;        // current temperature for simulated annealing
        private double alphaTemp    = 0.99;     // geometric coeff. for Temp, i.e. T1 = alpha * T0;
        private int stepsPerChg     = 100;      // no. of steps per temperature value
        private int currStep        = 0;        // current step within the stepsPerChg
        private int accepted        = 0;        // no. of accepted energy values
        private double currMomentum = 0;
        private double workMomentum = 0;
        private double bestMomentum = 0;
        private double currLrnRate  = 0;
        private double workLrnRate  = 0;
        private double bestLrnRate  = 0;
        private double currEnergy   = 999;      // current energy for simulated annealing
        private double workEnergy   = 999;      // working energy for simulated annealing
        private double bestEnergy   = 998;      // best (minimum) energy for simulated annealing
        private ArrayList AcceptedSA;           // no. of accepted energy values in sim annealing
        private ArrayList Temperature;          // List of temperatures
        private ArrayList MomentumSA;
        private ArrayList LearnRateSA;
        
        /* boolean flags */
        private bool fourlayer      = false;    // denotes NN with 2 hidden layers
        private bool firstrun       = true;     // denotes first time the start button is clicked
        private bool needtostop     = false;    //
        private bool fileerror      = false;    // error in data file... records cannot be read
        private bool minfound       = false;    //
        private bool pagechange     = false;    // true if a different tab is clicked
        private bool bipolar        = false;    // true for bipolar sigmoid function
        private bool sanneal        = false;    // true if simulated annealing selected   

        private double[,] inData;               // data records
        private double[,] normWt;               // normalized weights
        private double[,] PredictedTrainOut;    // predicted output values for training set
        private double[,] DesiredTestOut;       // desired output values for test set
        private double[,] PredictedTestOut;     // predicted output values for test set
        private double[,] PredictedMinTestOut;  // predicted output values for test set when error is at minimum
        private double[,] TestNeuOut;           // raw neuron output values for test set (before output de-normalization)

        private NeuralNetwork TheBrain  = new NeuralNetwork();  // NN object
        private NeuralNetwork MinBrain  = new NeuralNetwork();  // NN object saved for minimum error
        private Weight Wt               = null;                 // connection weights after training
        private Weight CurrWt           = null;                 // current weights
        private Weight MinWt            = null;                 // connection weights when error is minimum
        private Status pStatus          = Status.NotLoaded;

        private double[] tsterr;    // test error
        private double[] rmse;      // root-mean-sq-err
        private double[] sum;       // sum of errors in a epoch
        private double[] mean;      // mean error of epoch
        private double[] sse;       // sum-sq-err
        private double[] ssw;       // sum-sq-delta, delta = desired - mean
        private double[] rsq;       // R-squared
        private double[] coeffIn;   // coefficients of weighted/exponential moving average for input delay
        private double[] coeffOut;  // coefficients of weighted/exponential moving average for output delay

        private string[] colName;
        private string   outDir = @".";

        //
        //  status variables for Run & Weights menu and plots
        //
        private ArrayList[] ArrY;               // Y-coordinate of plot
        private double trnErrOK     = 0, trnErrNOK  = 0;
        private double testErrOK    = 0, testErrNOK = 0;
        private double errThresh    = 0.10;

        private System.Windows.Forms.Timer timer1 = null;   // system timer. free-running
        Stopwatch stopWatch = new Stopwatch();              // stopwatch
        Random randomNumber = new Random();

        // This delegate enables asynchronous calls for setting
        // the text property on a TextBox control.
        delegate void SetTextCallback(string text);

        private enum Status {
            NotLoaded,
            Loading,
            Loaded,
            SettingOK, 
            RefreshSettingOK, 
            Running, 
            NeedToStop, 
            Stopping, 
            Stopped
        };
        
        public class Weight
        {
            public double[,] In;        // connection between Input & Hidden1 layer
            public double[,] Hid;       // connection between Hidden1 & Hidden2 layer
            public double[,] Out;       // connection between Hidden1/Hidden2 & Output layer
            public double[] BiasIn;     // bias weights for input layer
            public double[] BiasHid;    // bias weights for hidden layer
            public double[] BiasOut;    // bias weights for output layer

            public ArrayList[,] ArrWtIntoHid;      // connection weights between input and 1st hidden layers
            public ArrayList[,] ArrWtHidtoHid2;    // connection weights between first and 2nd hidden layers
            public ArrayList[,] ArrWtHidtoOut;     // connection weights between hidden (1st or 2nd) and output layers

            public Weight(int inNodes, int hiddenNodes, int hiddenNodes2, int outNodes, Boolean fourlayer)
            {
                In = new double[inNodes, hiddenNodes];
                BiasIn = new double[hiddenNodes];

                ArrWtIntoHid = new ArrayList[inNodes, hiddenNodes];
                for (int i = 0; i < inNodes; i++)
                    for (int j = 0; j < hiddenNodes; j++)
                        ArrWtIntoHid[i, j] = new ArrayList();

                if (fourlayer)
                {
                    Hid = new double[hiddenNodes, hiddenNodes2];
                    BiasHid = new double[hiddenNodes2];

                    Out = new double[hiddenNodes2, outNodes];
                    BiasOut = new double[outNodes];

                    ArrWtHidtoHid2 = new ArrayList[hiddenNodes, hiddenNodes2];
                    ArrWtHidtoOut = new ArrayList[hiddenNodes2, outNodes];

                    for (int i = 0; i < hiddenNodes; i++)
                        for (int j = 0; j < hiddenNodes2; j++)
                            ArrWtHidtoHid2[i, j] = new ArrayList();

                    for (int i = 0; i < hiddenNodes2; i++)
                        for (int j = 0; j < outNodes; j++)
                            ArrWtHidtoOut[i, j] = new ArrayList();
                }
                else
                {
                    Out = new double[hiddenNodes, outNodes];
                    BiasOut = new double[outNodes];

                    ArrWtHidtoOut = new ArrayList[hiddenNodes, outNodes];

                    for (int i = 0; i < hiddenNodes; i++)
                        for (int j = 0; j < outNodes; j++)
                            ArrWtHidtoOut[i, j] = new ArrayList();
                }
            }
        }


    }
}