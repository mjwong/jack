using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using NPlot;

namespace rain2
{
    public partial class Form1
    {
        #region PlotGaussian
        public void PlotGaussian()
        {
            plotSurface2D2.Clear();
            
            /*
            int len = 35;
            System.Random r = new Random();
            double[] a = new double[len];
            double[] b = new double[len];

            for (int i = 0; i < len; ++i)
            {
                int j = len - 1 - i;
                a[i] = (double)Math.Exp(-(double)(i - len / 2) * (double)(i - len / 2) / 50.0f);
                b[i] = a[i] + (r.Next(10) / 50.0f) - 0.05f;
                if (b[i] < 0.0f)
                {
                    b[i] = 0;
                }
            }
            */

            HistogramPlot sp = new HistogramPlot();
            sp.DataSource = tsterr;
            sp.Pen = Pens.DarkBlue;
            sp.Filled = true;
            sp.RectangleBrush = new RectangleBrushes.HorizontalCenterFade(Color.Lavender, Color.Gold);
            sp.BaseWidth = 0.5f;
            sp.Label = "Error";
            /*
            LinePlot lp = new LinePlot();
            lp.DataSource = a;
            lp.Pen = new Pen(Color.Blue, 3.0f);
            lp.Label = "Gaussian Function";
            plotSurface2D2.Add(lp);
             */

            plotSurface2D2.Add(sp);

            //plotSurface2D2.Legend = new Legend();
            plotSurface2D2.YAxis1.WorldMin = 0.0f;
            plotSurface2D2.Title = "Histogram Test Error Plot";
            plotSurface2D2.AddInteraction(new NPlot.Windows.PlotSurface2D.Interactions.VerticalGuideline());
            plotSurface2D2.AddInteraction(new NPlot.Windows.PlotSurface2D.Interactions.HorizontalRangeSelection(3));
            plotSurface2D2.AddInteraction(new NPlot.Windows.PlotSurface2D.Interactions.AxisDrag(true));

        }
        #endregion
    }
}
