using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using NPlot;

namespace rain2
{
    public partial class Form1
    {

        // plot of desired vs predicted for output node 2
        // using training data.
        public void PlotWavelet6()
        {
            this.plotSurface2D6.Clear();

            Grid myGrid = new Grid();
            myGrid.VerticalGridType = Grid.GridType.Fine;
            myGrid.HorizontalGridType = Grid.GridType.Coarse;
            this.plotSurface2D6.Add(myGrid);

            double[] PlotY = new double[trainCnt];
            double[] PlotY2 = new double[trainCnt];

            // Output Neuron-1
            for (int i = 0; i < trainCnt; i++)
            {
                PlotY[i] = inData[i + trainSetStart, outColStart];
                if (currEpoch > 2)
                    PlotY2[i] = PredictedTrainOut[i + trainSetStart, 1];
                else
                    PlotY2[i] = 0.0f;
            }

            // Create a new line plot from array data via the ArrayAdapter class.
            LinePlot lp1 = new LinePlot();
            lp1.DataSource = PlotY;
            lp1.Color = Color.Blue;
            lp1.Label = "Desired";
            lp1.ShowInLegend = true;
            // And add it to the plot surface
            lock (PlotY)
            {
                this.plotSurface2D6.Add(lp1);
            }

            // Create a new line plot from array data via the ArrayAdapter class.
            LinePlot lp2 = new LinePlot();
            lp2.DataSource = PlotY2;
            lp2.Color = Color.Green;
            lp2.Label = "Predicted";
            lp2.ShowInLegend = true;
            // And add it to the plot surface
            lock (PlotY2)
            {
                this.plotSurface2D6.Add(lp2);
            }

            this.plotSurface2D6.Title = "Desired vs Predicted for Training Output-2";

            // Ok, the above will produce a decent default plot, but we would like to change
            // some of the Y Axis details. First, we'd like lots of small ticks (10) between 
            // large tick values. Secondly, we'd like to draw a grid for the Y values. To do 
            // this, we create a new LinearAxis (we could also use Label, Log etc). Rather than
            // starting from scratch, we use the constructor that takes an existing axis and
            // clones it (values in the superclass Axis only are cloned). PlotSurface2D
            // automatically determines a suitable axis when we add plots to it (merging
            // current requirements with old requirements), and we use this as our starting
            // point. Because we didn't specify which Y Axis we are using when we added the 
            // above line plot (there is one on the left - YAxis1 and one on the right - YAxis2)
            // PlotSurface2D.Add assumed we were using YAxis1. So, we create a new axis based on
            // YAxis1, update the details we want, then set the YAxis1 to be our updated one.
            LinearAxis myAxis = new LinearAxis(this.plotSurface2D6.YAxis1);
            myAxis.NumberOfSmallTicks = 10;
            this.plotSurface2D6.YAxis1 = myAxis;

            // We would also like to modify the way in which the X Axis is printed. This time,
            // we'll just modify the relevant PlotSurface2D Axis directly. 
            this.plotSurface2D6.XAxis1.WorldMax = trainCnt;

            this.plotSurface2D6.PlotBackColor = Color.Beige;
            this.plotSurface2D6.XAxis1.Reversed = false;
            this.plotSurface2D6.YAxis1.Reversed = false;
            this.plotSurface2D6.AddInteraction(new NPlot.Windows.PlotSurface2D.Interactions.VerticalGuideline());
            this.plotSurface2D6.AddInteraction(new NPlot.Windows.PlotSurface2D.Interactions.HorizontalRangeSelection(3));
            this.plotSurface2D6.AddInteraction(new NPlot.Windows.PlotSurface2D.Interactions.AxisDrag(true));

            plotSurface2D6.YAxis1.Label = "Output-2";
            plotSurface2D6.XAxis1.Label = "Training Record No.";

            Legend legend = new Legend();
            legend.AttachTo(PlotSurface2D.XAxisPosition.Top, PlotSurface2D.YAxisPosition.Right);
            legend.VerticalEdgePlacement = Legend.Placement.Outside;
            legend.HorizontalEdgePlacement = Legend.Placement.Outside;

            plotSurface2D6.Legend = legend;
        }

    }
}