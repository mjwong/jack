﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using NPlot;

namespace rain2
{
    public partial class Form1
    {
        // plot of connection wt between input and 1st hidden layer
        public void PlotWavelet8()
        {
            this.plotSurface2D8.Clear();

            Grid myGrid = new Grid();
            myGrid.VerticalGridType = Grid.GridType.Fine;
            myGrid.HorizontalGridType = Grid.GridType.Coarse;
            this.plotSurface2D8.Add(myGrid);
            
            // Create a new line plot from array data via the ArrayAdapter class.
            LinePlot[,] lp = new LinePlot[inNodes, hiddenNodes];
            for (int i = 0; i < inNodes; i++)
                for (int j = 0; j < hiddenNodes; j++)
                    lp[i, j] = new LinePlot();

            for (int i = 0; i < inNodes; i++)
                for (int j = 0; j < hiddenNodes; j++)
                {
                    lp[i, j].DataSource = CurrWt.ArrWtIntoHid[i, j];

                    lp[i,j].Color = PlotColor(j);
                    // And add it to the plot surface
                    lock (CurrWt)
                    {
                        lock (lp)
                        {
                            this.plotSurface2D8.Add(lp[i, j]);
                        }
                    }
                }

            this.plotSurface2D8.Title = "Input Weight Distribution";

            // Ok, the above will produce a decent default plot, but we would like to change
            // some of the Y Axis details. First, we'd like lots of small ticks (10) between 
            // large tick values. Secondly, we'd like to draw a grid for the Y values. To do 
            // this, we create a new LinearAxis (we could also use Label, Log etc). Rather than
            // starting from scratch, we use the constructor that takes an existing axis and
            // clones it (values in the superclass Axis only are cloned). PlotSurface2D
            // automatically determines a suitable axis when we add plots to it (merging
            // current requirements with old requirements), and we use this as our starting
            // point. Because we didn't specify which Y Axis we are using when we added the 
            // above line plot (there is one on the left - YAxis1 and one on the right - YAxis2)
            // PlotSurface2D.Add assumed we were using YAxis1. So, we create a new axis based on
            // YAxis1, update the details we want, then set the YAxis1 to be our updated one.
            LinearAxis myAxis = new LinearAxis(this.plotSurface2D8.YAxis1);
            myAxis.NumberOfSmallTicks = 10;
            this.plotSurface2D8.YAxis1 = myAxis;

            // We would also like to modify the way in which the X Axis is printed. This time,
            // we'll just modify the relevant PlotSurface2D Axis directly. 
            this.plotSurface2D8.XAxis1.WorldMax = iterations;

            this.plotSurface2D8.PlotBackColor = Color.Beige;
            this.plotSurface2D8.XAxis1.Reversed = false;
            this.plotSurface2D8.YAxis1.Reversed = false;
            this.plotSurface2D8.AddInteraction(new NPlot.Windows.PlotSurface2D.Interactions.VerticalGuideline());
            this.plotSurface2D8.AddInteraction(new NPlot.Windows.PlotSurface2D.Interactions.HorizontalRangeSelection(3));
            this.plotSurface2D8.AddInteraction(new NPlot.Windows.PlotSurface2D.Interactions.AxisDrag(true));

            plotSurface2D8.YAxis1.Label = "Weight";
            plotSurface2D8.XAxis1.Label = "Epoch";
        }


        public Color PlotColor(int i)
        {
            Color mycolor = new Color();
            switch (i)
            {
                case 0:
                    mycolor = Color.Blue;
                    break;

                case 1:
                    mycolor = Color.Green;
                    break;

                case 2:
                    mycolor = Color.Red;
                    break;

                case 3:
                    mycolor = Color.Yellow;
                    break;

                case 4:
                    mycolor = Color.Violet;
                    break;

                case 5:
                    mycolor = Color.Pink;
                    break;

                case 6:
                    mycolor = Color.PowderBlue;
                    break;

                case 7:
                    mycolor = Color.Orange;
                    break;

                case 8:
                    mycolor = Color.Olive;
                    break;

                case 9:
                    mycolor = Color.MediumOrchid;
                    break;

                case 10:
                    mycolor = Color.MediumSpringGreen;
                    break;

                case 11:
                    mycolor = Color.Navy;
                    break;

                case 12:
                    mycolor = Color.YellowGreen;
                    break;

                case 13:
                    mycolor = Color.Thistle;
                    break;

                case 14:
                    mycolor = Color.Teal;
                    break;

                case 15:
                    mycolor = Color.Turquoise;
                    break;

                case 16:
                    mycolor = Color.Tan;
                    break;

                case 17:
                    mycolor = Color.Tomato;
                    break;

                case 18:
                    mycolor = Color.SlateGray;
                    break;

                case 19:
                    mycolor = Color.PaleVioletRed;
                    break;

                default:
                    mycolor = Color.Plum;
                    break;

            }
            return mycolor;
        }


    }
}