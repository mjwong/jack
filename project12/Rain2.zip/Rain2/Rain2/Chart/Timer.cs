using System;
using System.Collections.Generic;
using System.Text;

namespace rain2
{
    public partial class Form1
    {
        private void InitializeTimer()
        {
            timer1 = new System.Windows.Forms.Timer();
            timer1.Enabled = true;
            timer1.Interval = frequency;
            // Hook up timer's tick event handler.
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
        }

        
        private void timer1_Tick(object sender, System.EventArgs e)
        {
            if (pStatus.Equals(Status.Running))
            {
                if (tabControl1.SelectedIndex == 3)
                    PlotWavelet();

                if (tabControl1.SelectedIndex == 7)
                {
                    PlotWavelet5();

                    if (outNodes > 1)
                        PlotWavelet6();
                }

                if (tabControl1.SelectedIndex == 8)
                {
                    PlotWavelet3();

                    if (outNodes > 1)
                        PlotWavelet4();
                }

                if (tabControl1.SelectedIndex == 9)
                {
                    PlotWavelet7();
                }

                 PlotGaussian();

                plotSurface2D1.Refresh();  // Force a re-draw of the control.
                plotSurface2D2.Refresh();
                plotSurface2D3.Refresh();
                plotSurface2D4.Refresh();
                plotSurface2D5.Refresh();
                plotSurface2D6.Refresh();
                plotSurface2D7.Refresh();
            }
        }
    }
}
