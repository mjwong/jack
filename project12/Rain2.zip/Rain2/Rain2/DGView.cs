using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Windows.Forms;

namespace rain2
{
    public partial class Form1
    {
        public bool DisplayData()
        {
            dataGridView1.DataSource = null;

            DataTable dt = new DataTable();
            for (int i = 0; i < attrCnt + 1; i++)
            {
                try
                {
                    dt.Columns.Add(new DataColumn(colName[i], typeof(double)));
                }
                catch (Exception e)
                {
                    MessageBox.Show("Check column name. " + e.Message);
                    return false;
                }
            }

            DataRow dr;
            for (int i = firstRec; i < readCnt; i++)
            {
                dr = dt.NewRow();
                if (firstRec == 0)
                    dr[colName[0]] = i + 1;
                else
                    dr[colName[0]] = i;

                for (int j = 0; j < attrCnt; j++)
                {
                    dr[colName[j+1]] = inData[i, j];
                }
                dt.Rows.Add(dr);
            }

            dataGridView1.DataSource = dt;
            dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.ColumnHeader);
            return true;
        }
        
        
        public void DisplayMaxMin()
        {
            dataGridView2.DataSource = null;
            string [] Descr = new string[3]{"Min", "Max", "Range"};

            DataTable dt2 = new DataTable();
            dt2.Columns.Add(new DataColumn("Descr", typeof(string)));
            for (int i = 1; i < attrCnt+1; i++)
                dt2.Columns.Add(new DataColumn(colName[i], typeof(double)));

            DataRow dr2;
            for (int i = 0; i < 3; i++)
            {
                dr2 = dt2.NewRow();
                dr2["Descr"] = Descr[i];
                for (int j = 0; j < attrCnt; j++)
                {
                    dr2[colName[j+1]] = Math.Round(normWt[i, j], 4);
                }
                dt2.Rows.Add(dr2);
            }

            dataGridView2.DataSource = dt2;
            dataGridView2.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.ColumnHeader);
        }


        public void DisplayResults()
        {
            int nodecnt = 0;
            dataGridView3.DataSource = null;
            String [] colName = new String[hiddenNodes+2];

            DataTable dt3 = new DataTable();
            for (int j = 0; j < hiddenNodes+2; j++)
            {
                if (j > 0)
                {
                    if (j == hiddenNodes + 1)
                        colName[j] = "Bias";
                    else
                        colName[j] = "Neuron" + Convert.ToString(j);
                }
                else
                    colName[0] = "Input";
                dt3.Columns.Add(new DataColumn(colName[j], typeof(double)));

            }

            DataRow dr3;
            for (int i = 0; i < inNodes; i++)
            {
                dr3 = dt3.NewRow();
                dr3[colName[0]] = i+1;

                for (int j = 1; j < hiddenNodes+1; j++)
                {
                    dr3[colName[j]] = Math.Round(Wt.In[i, j - 1], 6).ToString();
                }
                if (nodecnt < hiddenNodes)
                    dr3[colName[hiddenNodes + 1]] = Math.Round(Wt.BiasIn[nodecnt], 6).ToString();
                nodecnt++;
                dt3.Rows.Add(dr3);
            }

            if (inNodes < hiddenNodes)
                for (int i = nodecnt; i < hiddenNodes; i++)
                {
                    dr3 = dt3.NewRow();
                    dr3[colName[0]] = i + 1;
                    dr3[colName[hiddenNodes + 1]] = Math.Round(Wt.BiasIn[i], 6).ToString();
                    dt3.Rows.Add(dr3);
                }

            dataGridView3.DataSource = dt3;
            dataGridView3.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.ColumnHeader);
        }

        
        public void DisplayResults2()
        {
            int nodecnt = 0;
            dataGridView4.DataSource = null;
            String[] colName = new String[hiddenNodes2 + 2];

            DataTable dt4 = new DataTable();
            for (int j = 0; j < hiddenNodes2 + 2; j++)
            {
                if (j > 0)
                {
                    if (j == hiddenNodes2 + 1)
                        colName[j] = "Bias";
                    else
                        colName[j] = "Neuron" + Convert.ToString(j);
                }
                else
                    colName[0] = "Hidden";

                dt4.Columns.Add(new DataColumn(colName[j], typeof(double)));

            }

            DataRow dr4;
            for (int i = 0; i < hiddenNodes; i++)
            {
                dr4 = dt4.NewRow();
                dr4[colName[0]] = i + 1;

                for (int j = 1; j < hiddenNodes2 + 1; j++)
                {
                    dr4[colName[j]] = Math.Round(Wt.Hid[i, j - 1], 6).ToString();
                }

                if (nodecnt < hiddenNodes2)
                    dr4[colName[hiddenNodes2 + 1]] = Math.Round(Wt.BiasHid[nodecnt], 6).ToString();
                nodecnt++;
                dt4.Rows.Add(dr4);
            }

            if (hiddenNodes < hiddenNodes2)
                for (int i = nodecnt; i < hiddenNodes2; i++)
                {
                    dr4 = dt4.NewRow();
                    dr4[colName[0]] = i + 1;
                    dr4[colName[hiddenNodes2 + 1]] = Math.Round(Wt.BiasHid[i], 6).ToString();
                    dt4.Rows.Add(dr4);
                }

            dataGridView4.DataSource = dt4;
            dataGridView4.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.ColumnHeader);
        }


        public void DisplayResults3()
        {
            // connection weights between Hidden / Hidden Layer2 and Output
            int hiddenno = 0, nodecnt = 0;
            dataGridView7.DataSource = null;
            String[] colName = new String[outNodes + 2];

            DataTable dt7 = new DataTable();
            for (int j = 0; j < outNodes + 2; j++)
            {
                if (j > 0)
                {
                    if (j == outNodes + 1)
                        colName[j] = "Bias";
                    else
                        colName[j] = "Neuron" + Convert.ToString(j);
                }
                else
                    colName[0] = "Output";

                dt7.Columns.Add(new DataColumn(colName[j], typeof(double)));

            }

            DataRow dr7;
            if (fourlayer)
                hiddenno = hiddenNodes2;
            else
                hiddenno = hiddenNodes;

            for (int i = 0; i < hiddenno; i++)
            {
                dr7 = dt7.NewRow();
                dr7[colName[0]] = i + 1;

                for (int j = 1; j < outNodes + 1; j++)
                {
                    dr7[colName[j]] = Math.Round(Wt.Out[i, j - 1], 6).ToString();
                }

                if (nodecnt < outNodes)
                    dr7[colName[outNodes+1]] = Math.Round(Wt.BiasOut[nodecnt], 6).ToString();
                nodecnt++;

                dt7.Rows.Add(dr7);
            }

            if (hiddenNodes2 < outNodes)
                for (int i = nodecnt; i < outNodes; i++)
                {
                    dr7 = dt7.NewRow();
                    dr7[colName[0]] = i + 1;
                    dr7[colName[outNodes+1]] = Math.Round(Wt.BiasOut[i], 6).ToString();
                    dt7.Rows.Add(dr7);
                }
            dataGridView7.DataSource = dt7;
            dataGridView7.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.ColumnHeader);
        }


        public void DisplayResultsOutNeurons()
        {
            dataGridView5.DataSource = null;
            String[] colName = new String[outNodes + 1];

            DataTable dt5 = new DataTable();
            for (int j = 0; j < outNodes + 1; j++)
            {
                if (j > 0)
                    colName[j] = "Neuron" + Convert.ToString(j);
                else
                    colName[0] = "Test";
                dt5.Columns.Add(new DataColumn(colName[j], typeof(double)));

            }

            DataRow dr5;
            for (int i = 0; i < testCnt; i++)
            {
                dr5 = dt5.NewRow();
                dr5[colName[0]] = i;

                for (int j = 1; j < outNodes + 1; j++)
                {
                    dr5[colName[j]] = Math.Round(TestNeuOut[i, j - 1], 6).ToString();
                }
                dt5.Rows.Add(dr5);
            }

            dataGridView5.DataSource = dt5;
            dataGridView5.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.ColumnHeader);
        }


        public void DisplayResultsTest()
        {
            int col = 0;
            double predicted = 0.0f, desired = 0.0f;
            dataGridView6.DataSource = null;
            String[] colName = new String[outNodes*2 + 1];
            DataTable dt6 = new DataTable();
            DataRow dr6 = null;

            colName[0] = "No.";
            dt6.Columns.Add(new DataColumn(colName[0], typeof(double)));
            for (int j = 1; j < outNodes + 1; j++)
            {
                colName[j*2-1] = "Desired" + Convert.ToString(j);
                dt6.Columns.Add(new DataColumn(colName[j*2-1], typeof(double)));
                colName[j*2] = "Predicted" + Convert.ToString(j);
                dt6.Columns.Add(new DataColumn(colName[j*2], typeof(double)));
            }

            for (int i = 0; i < testCnt; i++)
            {
                dr6 = dt6.NewRow();
                dr6[colName[0]] = i;

                for (int j = 1; j < outNodes + 1; j++)
                {
                    col       = outColStart + j - 2;
                    desired   = inData[testSetStart + i, col];
                    predicted = PredictedTestOut[i, j - 1];
                    dr6[colName[j * 2 - 1]] = Math.Round(desired, 6).ToString();
                    dr6[colName[j * 2]]     = Math.Round(predicted, 6).ToString();
                }
                dt6.Rows.Add(dr6);
            }

            // last row displays the RMSE values
            dr6 = dt6.NewRow();
            for (int j = 0; j < outNodes; j++)
                dr6[colName[j * 2 + 1]] = Math.Round(rmse[j], 6).ToString();
            dt6.Rows.Add(dr6);

            dataGridView6.DataSource = dt6;
            dataGridView6.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.ColumnHeader);
        }
    }
}
