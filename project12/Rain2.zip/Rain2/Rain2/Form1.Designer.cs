namespace rain2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.bgWorker1 = new System.ComponentModel.BackgroundWorker();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.ColNamesBox = new System.Windows.Forms.CheckBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.LoadBtn = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label56 = new System.Windows.Forms.Label();
            this.TrainStartBox = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.TempAlphaBox = new System.Windows.Forms.TextBox();
            this.StartTempBox = new System.Windows.Forms.TextBox();
            this.freqBox = new System.Windows.Forms.TextBox();
            this.OutDirBox = new System.Windows.Forms.TextBox();
            this.TrainEndBox = new System.Windows.Forms.TextBox();
            this.EpochRMSEBox = new System.Windows.Forms.TextBox();
            this.RSFBox = new System.Windows.Forms.TextBox();
            this.OColStBox = new System.Windows.Forms.TextBox();
            this.ErrThresBox = new System.Windows.Forms.TextBox();
            this.HLayer2Box = new System.Windows.Forms.TextBox();
            this.EpochMinBox = new System.Windows.Forms.TextBox();
            this.TrainErrorBox = new System.Windows.Forms.TextBox();
            this.TrainTimeBox = new System.Windows.Forms.TextBox();
            this.IterationBox = new System.Windows.Forms.TextBox();
            this.TotalRecBox = new System.Windows.Forms.TextBox();
            this.TestEndBox = new System.Windows.Forms.TextBox();
            this.TestStartBox = new System.Windows.Forms.TextBox();
            this.AlphaBox = new System.Windows.Forms.TextBox();
            this.MomentumBox = new System.Windows.Forms.TextBox();
            this.LearnRateBox = new System.Windows.Forms.TextBox();
            this.HLayerBox = new System.Windows.Forms.TextBox();
            this.OColEndBox = new System.Windows.Forms.TextBox();
            this.InColBox = new System.Windows.Forms.TextBox();
            this.SAchkBox = new System.Windows.Forms.CheckBox();
            this.MTChkBox = new System.Windows.Forms.CheckBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.OutCboBox = new System.Windows.Forms.ComboBox();
            this.Hid2CboBox = new System.Windows.Forms.ComboBox();
            this.HidCboBox = new System.Windows.Forms.ComboBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.minPlotChkBox = new System.Windows.Forms.CheckBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.DefaultBtn = new System.Windows.Forms.Button();
            this.label35 = new System.Windows.Forms.Label();
            this.Architecture = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label47 = new System.Windows.Forms.Label();
            this.AlphaEMABox = new System.Windows.Forms.TextBox();
            this.NCRadBtn = new System.Windows.Forms.RadioButton();
            this.EMARadBtn = new System.Windows.Forms.RadioButton();
            this.WMARadBtn = new System.Windows.Forms.RadioButton();
            this.NARXBtn = new System.Windows.Forms.RadioButton();
            this.OutStepsBox = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.InStepsBox = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.BetaBox = new System.Windows.Forms.TextBox();
            this.TDLRadBtn = new System.Windows.Forms.RadioButton();
            this.RNNRadBtn = new System.Windows.Forms.RadioButton();
            this.MLFFRadBtn = new System.Windows.Forms.RadioButton();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.Layers4Box = new System.Windows.Forms.CheckBox();
            this.IntvChkBox = new System.Windows.Forms.CheckBox();
            this.PartChkBox = new System.Windows.Forms.CheckBox();
            this.RandChkBox = new System.Windows.Forms.CheckBox();
            this.OutColChkBox = new System.Windows.Forms.CheckBox();
            this.ParamSubmitBtn = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.label55 = new System.Windows.Forms.Label();
            this.SmapeBox = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.CMomentumBox = new System.Windows.Forms.TextBox();
            this.CLrnRateBox = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.RMSE2Box = new System.Windows.Forms.TextBox();
            this.RSq2Box = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.EpochMinRMSEBox = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.testNOKBox = new System.Windows.Forms.TextBox();
            this.testOKBox = new System.Windows.Forms.TextBox();
            this.trnNOKBox = new System.Windows.Forms.TextBox();
            this.trnOKBox = new System.Windows.Forms.TextBox();
            this.StartBtn = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.AvgTestErrBox = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.RMSE1Box = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.RSq1Box = new System.Windows.Forms.TextBox();
            this.AvgTrainErrBox = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.minErrBox = new System.Windows.Forms.TextBox();
            this.EpochSMBox = new System.Windows.Forms.TextBox();
            this.TimeBox = new System.Windows.Forms.TextBox();
            this.EpochsBox = new System.Windows.Forms.TextBox();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.plotSurface2D1 = new NPlot.Windows.PlotSurface2D();
            this.plotSurface2D2 = new NPlot.Windows.PlotSurface2D();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.splitContainer7 = new System.Windows.Forms.SplitContainer();
            this.plotSurface2D5 = new NPlot.Windows.PlotSurface2D();
            this.plotSurface2D6 = new NPlot.Windows.PlotSurface2D();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.splitContainer8 = new System.Windows.Forms.SplitContainer();
            this.plotSurface2D3 = new NPlot.Windows.PlotSurface2D();
            this.plotSurface2D4 = new NPlot.Windows.PlotSurface2D();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.plotSurface2D7 = new NPlot.Windows.PlotSurface2D();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.plotSurface2D8 = new NPlot.Windows.PlotSurface2D();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.plotSurface2D9 = new NPlot.Windows.PlotSurface2D();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.statusStrip1.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.Architecture.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.tabPage8.SuspendLayout();
            this.splitContainer7.Panel1.SuspendLayout();
            this.splitContainer7.Panel2.SuspendLayout();
            this.splitContainer7.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.splitContainer8.Panel1.SuspendLayout();
            this.splitContainer8.Panel2.SuspendLayout();
            this.splitContainer8.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 692);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(984, 22);
            this.statusStrip1.TabIndex = 7;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(51, 17);
            this.toolStripStatusLabel1.Text = "Status:   ";
            this.toolStripStatusLabel1.MouseEnter += new System.EventHandler(this.toolStripStatusLabel1_MouseEnter);
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(0, 17);
            // 
            // bgWorker1
            // 
            this.bgWorker1.WorkerReportsProgress = true;
            this.bgWorker1.WorkerSupportsCancellation = true;
            this.bgWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgWorker1_DoWork);
            this.bgWorker1.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgWorker1_RunWorkerCompleted);
            this.bgWorker1.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.bgWorker1_ProgressChanged);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tabControl1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.richTextBox1);
            this.splitContainer1.Size = new System.Drawing.Size(984, 692);
            this.splitContainer1.SplitterDistance = 594;
            this.splitContainer1.TabIndex = 8;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Controls.Add(this.tabPage11);
            this.tabControl1.Controls.Add(this.tabPage12);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(984, 594);
            this.tabControl1.TabIndex = 9;
            this.tabControl1.TabIndexChanged += new System.EventHandler(this.tabControl1_TabIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.ColNamesBox);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.LoadBtn);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(976, 568);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "DataView";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // ColNamesBox
            // 
            this.ColNamesBox.AutoSize = true;
            this.ColNamesBox.Location = new System.Drawing.Point(119, 536);
            this.ColNamesBox.Name = "ColNamesBox";
            this.ColNamesBox.Size = new System.Drawing.Size(187, 17);
            this.ColNamesBox.TabIndex = 13;
            this.ColNamesBox.Text = "First Row contains Column Names";
            this.ColNamesBox.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(970, 510);
            this.dataGridView1.TabIndex = 12;
            // 
            // LoadBtn
            // 
            this.LoadBtn.Location = new System.Drawing.Point(6, 532);
            this.LoadBtn.Name = "LoadBtn";
            this.LoadBtn.Size = new System.Drawing.Size(75, 23);
            this.LoadBtn.TabIndex = 11;
            this.LoadBtn.Text = "Load";
            this.LoadBtn.UseVisualStyleBackColor = true;
            this.LoadBtn.Click += new System.EventHandler(this.LoadBtn_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(976, 568);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "MaxMin";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(3, 3);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(970, 562);
            this.dataGridView2.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label56);
            this.tabPage3.Controls.Add(this.TrainStartBox);
            this.tabPage3.Controls.Add(this.label54);
            this.tabPage3.Controls.Add(this.label31);
            this.tabPage3.Controls.Add(this.TempAlphaBox);
            this.tabPage3.Controls.Add(this.StartTempBox);
            this.tabPage3.Controls.Add(this.freqBox);
            this.tabPage3.Controls.Add(this.OutDirBox);
            this.tabPage3.Controls.Add(this.TrainEndBox);
            this.tabPage3.Controls.Add(this.EpochRMSEBox);
            this.tabPage3.Controls.Add(this.RSFBox);
            this.tabPage3.Controls.Add(this.OColStBox);
            this.tabPage3.Controls.Add(this.ErrThresBox);
            this.tabPage3.Controls.Add(this.HLayer2Box);
            this.tabPage3.Controls.Add(this.EpochMinBox);
            this.tabPage3.Controls.Add(this.TrainErrorBox);
            this.tabPage3.Controls.Add(this.TrainTimeBox);
            this.tabPage3.Controls.Add(this.IterationBox);
            this.tabPage3.Controls.Add(this.TotalRecBox);
            this.tabPage3.Controls.Add(this.TestEndBox);
            this.tabPage3.Controls.Add(this.TestStartBox);
            this.tabPage3.Controls.Add(this.AlphaBox);
            this.tabPage3.Controls.Add(this.MomentumBox);
            this.tabPage3.Controls.Add(this.LearnRateBox);
            this.tabPage3.Controls.Add(this.HLayerBox);
            this.tabPage3.Controls.Add(this.OColEndBox);
            this.tabPage3.Controls.Add(this.InColBox);
            this.tabPage3.Controls.Add(this.SAchkBox);
            this.tabPage3.Controls.Add(this.MTChkBox);
            this.tabPage3.Controls.Add(this.label51);
            this.tabPage3.Controls.Add(this.label50);
            this.tabPage3.Controls.Add(this.label49);
            this.tabPage3.Controls.Add(this.label48);
            this.tabPage3.Controls.Add(this.OutCboBox);
            this.tabPage3.Controls.Add(this.Hid2CboBox);
            this.tabPage3.Controls.Add(this.HidCboBox);
            this.tabPage3.Controls.Add(this.label43);
            this.tabPage3.Controls.Add(this.label44);
            this.tabPage3.Controls.Add(this.label45);
            this.tabPage3.Controls.Add(this.label46);
            this.tabPage3.Controls.Add(this.minPlotChkBox);
            this.tabPage3.Controls.Add(this.label38);
            this.tabPage3.Controls.Add(this.label37);
            this.tabPage3.Controls.Add(this.DefaultBtn);
            this.tabPage3.Controls.Add(this.label35);
            this.tabPage3.Controls.Add(this.Architecture);
            this.tabPage3.Controls.Add(this.label33);
            this.tabPage3.Controls.Add(this.label32);
            this.tabPage3.Controls.Add(this.label25);
            this.tabPage3.Controls.Add(this.Layers4Box);
            this.tabPage3.Controls.Add(this.IntvChkBox);
            this.tabPage3.Controls.Add(this.PartChkBox);
            this.tabPage3.Controls.Add(this.RandChkBox);
            this.tabPage3.Controls.Add(this.OutColChkBox);
            this.tabPage3.Controls.Add(this.ParamSubmitBtn);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(976, 568);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Parameters";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(336, 435);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(114, 13);
            this.label56.TabIndex = 135;
            this.label56.Text = "Training Set Start Row";
            // 
            // TrainStartBox
            // 
            this.TrainStartBox.Location = new System.Drawing.Point(500, 432);
            this.TrainStartBox.Name = "TrainStartBox";
            this.TrainStartBox.Size = new System.Drawing.Size(100, 20);
            this.TrainStartBox.TabIndex = 134;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(14, 393);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(92, 13);
            this.label54.TabIndex = 133;
            this.label54.Text = "Alpha Temp Coef.";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(14, 367);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(92, 13);
            this.label31.TabIndex = 132;
            this.label31.Text = "Start Temperature";
            // 
            // TempAlphaBox
            // 
            this.TempAlphaBox.Location = new System.Drawing.Point(178, 390);
            this.TempAlphaBox.Name = "TempAlphaBox";
            this.TempAlphaBox.Size = new System.Drawing.Size(100, 20);
            this.TempAlphaBox.TabIndex = 131;
            // 
            // StartTempBox
            // 
            this.StartTempBox.Location = new System.Drawing.Point(178, 364);
            this.StartTempBox.Name = "StartTempBox";
            this.StartTempBox.Size = new System.Drawing.Size(100, 20);
            this.StartTempBox.TabIndex = 130;
            // 
            // freqBox
            // 
            this.freqBox.Location = new System.Drawing.Point(840, 258);
            this.freqBox.Name = "freqBox";
            this.freqBox.Size = new System.Drawing.Size(100, 20);
            this.freqBox.TabIndex = 125;
            // 
            // OutDirBox
            // 
            this.OutDirBox.Location = new System.Drawing.Point(679, 302);
            this.OutDirBox.Name = "OutDirBox";
            this.OutDirBox.Size = new System.Drawing.Size(261, 20);
            this.OutDirBox.TabIndex = 122;
            this.OutDirBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.OutDirBox_MouseClick);
            // 
            // TrainEndBox
            // 
            this.TrainEndBox.Location = new System.Drawing.Point(500, 458);
            this.TrainEndBox.Name = "TrainEndBox";
            this.TrainEndBox.Size = new System.Drawing.Size(100, 20);
            this.TrainEndBox.TabIndex = 121;
            this.TrainEndBox.TextChanged += new System.EventHandler(this.TrainEndBox_TextChanged);
            // 
            // EpochRMSEBox
            // 
            this.EpochRMSEBox.Location = new System.Drawing.Point(840, 149);
            this.EpochRMSEBox.Name = "EpochRMSEBox";
            this.EpochRMSEBox.Size = new System.Drawing.Size(100, 20);
            this.EpochRMSEBox.TabIndex = 107;
            // 
            // RSFBox
            // 
            this.RSFBox.Location = new System.Drawing.Point(178, 198);
            this.RSFBox.Name = "RSFBox";
            this.RSFBox.Size = new System.Drawing.Size(100, 20);
            this.RSFBox.TabIndex = 106;
            // 
            // OColStBox
            // 
            this.OColStBox.Location = new System.Drawing.Point(178, 94);
            this.OColStBox.Name = "OColStBox";
            this.OColStBox.Size = new System.Drawing.Size(100, 20);
            this.OColStBox.TabIndex = 102;
            // 
            // ErrThresBox
            // 
            this.ErrThresBox.Location = new System.Drawing.Point(840, 175);
            this.ErrThresBox.Name = "ErrThresBox";
            this.ErrThresBox.Size = new System.Drawing.Size(100, 20);
            this.ErrThresBox.TabIndex = 98;
            // 
            // HLayer2Box
            // 
            this.HLayer2Box.Location = new System.Drawing.Point(178, 172);
            this.HLayer2Box.Name = "HLayer2Box";
            this.HLayer2Box.Size = new System.Drawing.Size(100, 20);
            this.HLayer2Box.TabIndex = 96;
            // 
            // EpochMinBox
            // 
            this.EpochMinBox.Location = new System.Drawing.Point(840, 123);
            this.EpochMinBox.Name = "EpochMinBox";
            this.EpochMinBox.Size = new System.Drawing.Size(100, 20);
            this.EpochMinBox.TabIndex = 83;
            // 
            // TrainErrorBox
            // 
            this.TrainErrorBox.Location = new System.Drawing.Point(840, 97);
            this.TrainErrorBox.Name = "TrainErrorBox";
            this.TrainErrorBox.Size = new System.Drawing.Size(100, 20);
            this.TrainErrorBox.TabIndex = 82;
            // 
            // TrainTimeBox
            // 
            this.TrainTimeBox.Location = new System.Drawing.Point(840, 71);
            this.TrainTimeBox.Name = "TrainTimeBox";
            this.TrainTimeBox.Size = new System.Drawing.Size(100, 20);
            this.TrainTimeBox.TabIndex = 80;
            // 
            // IterationBox
            // 
            this.IterationBox.Location = new System.Drawing.Point(840, 45);
            this.IterationBox.Name = "IterationBox";
            this.IterationBox.Size = new System.Drawing.Size(100, 20);
            this.IterationBox.TabIndex = 77;
            // 
            // TotalRecBox
            // 
            this.TotalRecBox.Location = new System.Drawing.Point(500, 535);
            this.TotalRecBox.Name = "TotalRecBox";
            this.TotalRecBox.Size = new System.Drawing.Size(100, 20);
            this.TotalRecBox.TabIndex = 76;
            // 
            // TestEndBox
            // 
            this.TestEndBox.Location = new System.Drawing.Point(500, 510);
            this.TestEndBox.Name = "TestEndBox";
            this.TestEndBox.Size = new System.Drawing.Size(100, 20);
            this.TestEndBox.TabIndex = 67;
            // 
            // TestStartBox
            // 
            this.TestStartBox.Location = new System.Drawing.Point(500, 484);
            this.TestStartBox.Name = "TestStartBox";
            this.TestStartBox.Size = new System.Drawing.Size(100, 20);
            this.TestStartBox.TabIndex = 66;
            this.TestStartBox.TextChanged += new System.EventHandler(this.TestStartBox_TextChanged);
            // 
            // AlphaBox
            // 
            this.AlphaBox.Location = new System.Drawing.Point(178, 338);
            this.AlphaBox.Name = "AlphaBox";
            this.AlphaBox.Size = new System.Drawing.Size(100, 20);
            this.AlphaBox.TabIndex = 65;
            // 
            // MomentumBox
            // 
            this.MomentumBox.Location = new System.Drawing.Point(178, 312);
            this.MomentumBox.Name = "MomentumBox";
            this.MomentumBox.Size = new System.Drawing.Size(100, 20);
            this.MomentumBox.TabIndex = 64;
            // 
            // LearnRateBox
            // 
            this.LearnRateBox.Location = new System.Drawing.Point(178, 286);
            this.LearnRateBox.Name = "LearnRateBox";
            this.LearnRateBox.Size = new System.Drawing.Size(100, 20);
            this.LearnRateBox.TabIndex = 63;
            // 
            // HLayerBox
            // 
            this.HLayerBox.Location = new System.Drawing.Point(178, 146);
            this.HLayerBox.Name = "HLayerBox";
            this.HLayerBox.Size = new System.Drawing.Size(100, 20);
            this.HLayerBox.TabIndex = 62;
            // 
            // OColEndBox
            // 
            this.OColEndBox.Location = new System.Drawing.Point(178, 120);
            this.OColEndBox.Name = "OColEndBox";
            this.OColEndBox.Size = new System.Drawing.Size(100, 20);
            this.OColEndBox.TabIndex = 61;
            // 
            // InColBox
            // 
            this.InColBox.Location = new System.Drawing.Point(178, 68);
            this.InColBox.Name = "InColBox";
            this.InColBox.Size = new System.Drawing.Size(100, 20);
            this.InColBox.TabIndex = 60;
            // 
            // SAchkBox
            // 
            this.SAchkBox.AutoSize = true;
            this.SAchkBox.Location = new System.Drawing.Point(17, 264);
            this.SAchkBox.Name = "SAchkBox";
            this.SAchkBox.Size = new System.Drawing.Size(122, 17);
            this.SAchkBox.TabIndex = 129;
            this.SAchkBox.Text = "Simulated Annealing";
            this.SAchkBox.UseVisualStyleBackColor = true;
            this.SAchkBox.CheckedChanged += new System.EventHandler(this.SAchkBox_CheckedChanged);
            // 
            // MTChkBox
            // 
            this.MTChkBox.AutoSize = true;
            this.MTChkBox.Location = new System.Drawing.Point(679, 352);
            this.MTChkBox.Name = "MTChkBox";
            this.MTChkBox.Size = new System.Drawing.Size(99, 17);
            this.MTChkBox.TabIndex = 127;
            this.MTChkBox.Text = "Multi-Threading";
            this.MTChkBox.UseVisualStyleBackColor = true;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(676, 261);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(126, 13);
            this.label51.TabIndex = 126;
            this.label51.Text = "Plot Update Interval  (ms)";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label50.Location = new System.Drawing.Point(676, 232);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(37, 15);
            this.label50.TabIndex = 124;
            this.label50.Text = "Misc";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(676, 284);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(58, 13);
            this.label49.TabIndex = 123;
            this.label49.Text = "Output Dir:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(336, 461);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(111, 13);
            this.label48.TabIndex = 120;
            this.label48.Text = "Training Set End Row";
            // 
            // OutCboBox
            // 
            this.OutCboBox.FormattingEnabled = true;
            this.OutCboBox.Items.AddRange(new object[] {
            "Sigmoid",
            "Tanh",
            "Linear",
            "Bipolar-Sigmoid"});
            this.OutCboBox.Location = new System.Drawing.Point(157, 529);
            this.OutCboBox.Name = "OutCboBox";
            this.OutCboBox.Size = new System.Drawing.Size(121, 21);
            this.OutCboBox.TabIndex = 119;
            // 
            // Hid2CboBox
            // 
            this.Hid2CboBox.FormattingEnabled = true;
            this.Hid2CboBox.Items.AddRange(new object[] {
            "Sigmoid",
            "Tanh",
            "Linear",
            "Bipolar-Sigmoid"});
            this.Hid2CboBox.Location = new System.Drawing.Point(157, 503);
            this.Hid2CboBox.Name = "Hid2CboBox";
            this.Hid2CboBox.Size = new System.Drawing.Size(121, 21);
            this.Hid2CboBox.TabIndex = 118;
            // 
            // HidCboBox
            // 
            this.HidCboBox.FormattingEnabled = true;
            this.HidCboBox.Items.AddRange(new object[] {
            "Sigmoid",
            "Tanh",
            "Linear",
            "Bipolar-Sigmoid"});
            this.HidCboBox.Location = new System.Drawing.Point(157, 477);
            this.HidCboBox.Name = "HidCboBox";
            this.HidCboBox.Size = new System.Drawing.Size(121, 21);
            this.HidCboBox.TabIndex = 117;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label43.Location = new System.Drawing.Point(14, 452);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(127, 15);
            this.label43.TabIndex = 116;
            this.label43.Text = "Activation Function";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(14, 532);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(68, 13);
            this.label44.TabIndex = 115;
            this.label44.Text = "Output Layer";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(14, 506);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(91, 13);
            this.label45.TabIndex = 114;
            this.label45.Text = "2nd Hidden Layer";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(14, 480);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(70, 13);
            this.label46.TabIndex = 113;
            this.label46.Text = "Hidden Layer";
            // 
            // minPlotChkBox
            // 
            this.minPlotChkBox.AutoSize = true;
            this.minPlotChkBox.Location = new System.Drawing.Point(679, 329);
            this.minPlotChkBox.Name = "minPlotChkBox";
            this.minPlotChkBox.Size = new System.Drawing.Size(192, 17);
            this.minPlotChkBox.TabIndex = 109;
            this.minPlotChkBox.Text = "Plot predicted values @ min RMSE";
            this.minPlotChkBox.UseVisualStyleBackColor = true;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(676, 152);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(157, 13);
            this.label38.TabIndex = 108;
            this.label38.Text = "Epochs since min. RMSE (Test)";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(14, 201);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(102, 13);
            this.label37.TabIndex = 105;
            this.label37.Text = "Range Scale Factor";
            // 
            // DefaultBtn
            // 
            this.DefaultBtn.Location = new System.Drawing.Point(679, 398);
            this.DefaultBtn.Name = "DefaultBtn";
            this.DefaultBtn.Size = new System.Drawing.Size(100, 37);
            this.DefaultBtn.TabIndex = 104;
            this.DefaultBtn.Text = "Default";
            this.DefaultBtn.UseVisualStyleBackColor = true;
            this.DefaultBtn.Click += new System.EventHandler(this.DefaultBtn_Click);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(14, 97);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(102, 13);
            this.label35.TabIndex = 103;
            this.label35.Text = "Output Column Start";
            // 
            // Architecture
            // 
            this.Architecture.Controls.Add(this.groupBox1);
            this.Architecture.Controls.Add(this.NARXBtn);
            this.Architecture.Controls.Add(this.OutStepsBox);
            this.Architecture.Controls.Add(this.label40);
            this.Architecture.Controls.Add(this.label36);
            this.Architecture.Controls.Add(this.InStepsBox);
            this.Architecture.Controls.Add(this.label34);
            this.Architecture.Controls.Add(this.BetaBox);
            this.Architecture.Controls.Add(this.TDLRadBtn);
            this.Architecture.Controls.Add(this.RNNRadBtn);
            this.Architecture.Controls.Add(this.MLFFRadBtn);
            this.Architecture.Location = new System.Drawing.Point(339, 45);
            this.Architecture.Name = "Architecture";
            this.Architecture.Size = new System.Drawing.Size(279, 322);
            this.Architecture.TabIndex = 101;
            this.Architecture.TabStop = false;
            this.Architecture.Text = "Architecture";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label47);
            this.groupBox1.Controls.Add(this.AlphaEMABox);
            this.groupBox1.Controls.Add(this.NCRadBtn);
            this.groupBox1.Controls.Add(this.EMARadBtn);
            this.groupBox1.Controls.Add(this.WMARadBtn);
            this.groupBox1.Location = new System.Drawing.Point(9, 196);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(264, 117);
            this.groupBox1.TabIndex = 73;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Coeff. of delay elements";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(3, 90);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(65, 13);
            this.label47.TabIndex = 73;
            this.label47.Text = "Alpha Coeff.";
            // 
            // AlphaEMABox
            // 
            this.AlphaEMABox.Location = new System.Drawing.Point(152, 87);
            this.AlphaEMABox.Name = "AlphaEMABox";
            this.AlphaEMABox.Size = new System.Drawing.Size(100, 20);
            this.AlphaEMABox.TabIndex = 72;
            // 
            // NCRadBtn
            // 
            this.NCRadBtn.AutoSize = true;
            this.NCRadBtn.Location = new System.Drawing.Point(6, 18);
            this.NCRadBtn.Name = "NCRadBtn";
            this.NCRadBtn.Size = new System.Drawing.Size(51, 17);
            this.NCRadBtn.TabIndex = 2;
            this.NCRadBtn.TabStop = true;
            this.NCRadBtn.Text = "None";
            this.NCRadBtn.UseVisualStyleBackColor = true;
            // 
            // EMARadBtn
            // 
            this.EMARadBtn.AutoSize = true;
            this.EMARadBtn.Location = new System.Drawing.Point(6, 64);
            this.EMARadBtn.Name = "EMARadBtn";
            this.EMARadBtn.Size = new System.Drawing.Size(161, 17);
            this.EMARadBtn.TabIndex = 1;
            this.EMARadBtn.TabStop = true;
            this.EMARadBtn.Text = "Exponential Moving Average";
            this.EMARadBtn.UseVisualStyleBackColor = true;
            this.EMARadBtn.CheckedChanged += new System.EventHandler(this.EMARadBtn_CheckedChanged);
            // 
            // WMARadBtn
            // 
            this.WMARadBtn.AutoSize = true;
            this.WMARadBtn.Location = new System.Drawing.Point(6, 41);
            this.WMARadBtn.Name = "WMARadBtn";
            this.WMARadBtn.Size = new System.Drawing.Size(152, 17);
            this.WMARadBtn.TabIndex = 0;
            this.WMARadBtn.TabStop = true;
            this.WMARadBtn.Text = "Weighted Moving Average";
            this.WMARadBtn.UseVisualStyleBackColor = true;
            // 
            // NARXBtn
            // 
            this.NARXBtn.AutoSize = true;
            this.NARXBtn.Location = new System.Drawing.Point(6, 88);
            this.NARXBtn.Name = "NARXBtn";
            this.NARXBtn.Size = new System.Drawing.Size(55, 17);
            this.NARXBtn.TabIndex = 72;
            this.NARXBtn.TabStop = true;
            this.NARXBtn.Text = "NARX";
            this.NARXBtn.UseVisualStyleBackColor = true;
            this.NARXBtn.CheckedChanged += new System.EventHandler(this.NARXBtn_CheckedChanged);
            // 
            // OutStepsBox
            // 
            this.OutStepsBox.Location = new System.Drawing.Point(161, 170);
            this.OutStepsBox.Name = "OutStepsBox";
            this.OutStepsBox.Size = new System.Drawing.Size(100, 20);
            this.OutStepsBox.TabIndex = 71;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(6, 173);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(111, 13);
            this.label40.TabIndex = 70;
            this.label40.Text = "Output FB Time Steps";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(6, 147);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(87, 13);
            this.label36.TabIndex = 69;
            this.label36.Text = "Input Time Steps";
            // 
            // InStepsBox
            // 
            this.InStepsBox.Location = new System.Drawing.Point(161, 144);
            this.InStepsBox.Name = "InStepsBox";
            this.InStepsBox.Size = new System.Drawing.Size(100, 20);
            this.InStepsBox.TabIndex = 68;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(6, 121);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(127, 13);
            this.label34.TabIndex = 67;
            this.label34.Text = "RNN Feedback Constant";
            // 
            // BetaBox
            // 
            this.BetaBox.Location = new System.Drawing.Point(161, 118);
            this.BetaBox.Name = "BetaBox";
            this.BetaBox.Size = new System.Drawing.Size(100, 20);
            this.BetaBox.TabIndex = 66;
            // 
            // TDLRadBtn
            // 
            this.TDLRadBtn.AutoSize = true;
            this.TDLRadBtn.Location = new System.Drawing.Point(6, 65);
            this.TDLRadBtn.Name = "TDLRadBtn";
            this.TDLRadBtn.Size = new System.Drawing.Size(115, 17);
            this.TDLRadBtn.TabIndex = 2;
            this.TDLRadBtn.TabStop = true;
            this.TDLRadBtn.Text = "Tapped Delay Line";
            this.TDLRadBtn.UseVisualStyleBackColor = true;
            this.TDLRadBtn.CheckedChanged += new System.EventHandler(this.TDLRadBtn_CheckedChanged);
            // 
            // RNNRadBtn
            // 
            this.RNNRadBtn.AutoSize = true;
            this.RNNRadBtn.Location = new System.Drawing.Point(6, 42);
            this.RNNRadBtn.Name = "RNNRadBtn";
            this.RNNRadBtn.Size = new System.Drawing.Size(49, 17);
            this.RNNRadBtn.TabIndex = 1;
            this.RNNRadBtn.TabStop = true;
            this.RNNRadBtn.Text = "RNN";
            this.RNNRadBtn.UseVisualStyleBackColor = true;
            this.RNNRadBtn.CheckedChanged += new System.EventHandler(this.RNNRadBtn_CheckedChanged);
            // 
            // MLFFRadBtn
            // 
            this.MLFFRadBtn.AutoSize = true;
            this.MLFFRadBtn.Location = new System.Drawing.Point(6, 19);
            this.MLFFRadBtn.Name = "MLFFRadBtn";
            this.MLFFRadBtn.Size = new System.Drawing.Size(78, 17);
            this.MLFFRadBtn.TabIndex = 0;
            this.MLFFRadBtn.TabStop = true;
            this.MLFFRadBtn.Text = "MLFF + BP";
            this.MLFFRadBtn.UseVisualStyleBackColor = true;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(336, 20);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(46, 13);
            this.label33.TabIndex = 100;
            this.label33.Text = "Design";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(676, 178);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(79, 13);
            this.label32.TabIndex = 99;
            this.label32.Text = "Error Threshold";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(14, 175);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(134, 13);
            this.label25.TabIndex = 97;
            this.label25.Text = "2nd Hidden Layer Neurons";
            // 
            // Layers4Box
            // 
            this.Layers4Box.AutoSize = true;
            this.Layers4Box.Location = new System.Drawing.Point(168, 45);
            this.Layers4Box.Name = "Layers4Box";
            this.Layers4Box.Size = new System.Drawing.Size(103, 17);
            this.Layers4Box.TabIndex = 95;
            this.Layers4Box.Text = "2 Hidden Layers";
            this.Layers4Box.UseVisualStyleBackColor = true;
            this.Layers4Box.CheckedChanged += new System.EventHandler(this.Layers4Box_CheckedChanged);
            // 
            // IntvChkBox
            // 
            this.IntvChkBox.AutoSize = true;
            this.IntvChkBox.Location = new System.Drawing.Point(433, 409);
            this.IntvChkBox.Name = "IntvChkBox";
            this.IntvChkBox.Size = new System.Drawing.Size(73, 17);
            this.IntvChkBox.TabIndex = 94;
            this.IntvChkBox.Text = "Interleave";
            this.IntvChkBox.UseVisualStyleBackColor = true;
            // 
            // PartChkBox
            // 
            this.PartChkBox.AutoSize = true;
            this.PartChkBox.Location = new System.Drawing.Point(521, 409);
            this.PartChkBox.Name = "PartChkBox";
            this.PartChkBox.Size = new System.Drawing.Size(115, 17);
            this.PartChkBox.TabIndex = 93;
            this.PartChkBox.Text = "Partition Set 70/20";
            this.PartChkBox.UseVisualStyleBackColor = true;
            // 
            // RandChkBox
            // 
            this.RandChkBox.AutoSize = true;
            this.RandChkBox.Location = new System.Drawing.Point(339, 409);
            this.RandChkBox.Name = "RandChkBox";
            this.RandChkBox.Size = new System.Drawing.Size(79, 17);
            this.RandChkBox.TabIndex = 92;
            this.RandChkBox.Text = "Randomize";
            this.RandChkBox.UseVisualStyleBackColor = true;
            // 
            // OutColChkBox
            // 
            this.OutColChkBox.AutoSize = true;
            this.OutColChkBox.Location = new System.Drawing.Point(17, 45);
            this.OutColChkBox.Name = "OutColChkBox";
            this.OutColChkBox.Size = new System.Drawing.Size(119, 17);
            this.OutColChkBox.TabIndex = 91;
            this.OutColChkBox.Text = "Output Last Column";
            this.OutColChkBox.UseVisualStyleBackColor = true;
            // 
            // ParamSubmitBtn
            // 
            this.ParamSubmitBtn.Location = new System.Drawing.Point(807, 398);
            this.ParamSubmitBtn.Name = "ParamSubmitBtn";
            this.ParamSubmitBtn.Size = new System.Drawing.Size(100, 37);
            this.ParamSubmitBtn.TabIndex = 90;
            this.ParamSubmitBtn.Text = "Submit";
            this.ParamSubmitBtn.UseVisualStyleBackColor = true;
            this.ParamSubmitBtn.Click += new System.EventHandler(this.ParamSubmitBtn_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(676, 18);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 15);
            this.label17.TabIndex = 89;
            this.label17.Text = "Execution";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(336, 382);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(105, 15);
            this.label16.TabIndex = 88;
            this.label16.Text = "Data Extraction";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(14, 241);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(64, 15);
            this.label15.TabIndex = 87;
            this.label15.Text = "Learning";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(14, 18);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(39, 15);
            this.label14.TabIndex = 86;
            this.label14.Text = "Input";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(676, 126);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(126, 13);
            this.label13.TabIndex = 85;
            this.label13.Text = "Epochs since min. (Train)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(676, 100);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 13);
            this.label12.TabIndex = 84;
            this.label12.Text = "Training Error";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(676, 74);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 13);
            this.label11.TabIndex = 81;
            this.label11.Text = "Training Time (min)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(676, 48);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 13);
            this.label10.TabIndex = 79;
            this.label10.Text = "Iterations";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(336, 538);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 13);
            this.label9.TabIndex = 78;
            this.label9.Text = "Total Records";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(336, 513);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 13);
            this.label8.TabIndex = 75;
            this.label8.Text = "Test Set End Row";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(336, 487);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 13);
            this.label7.TabIndex = 74;
            this.label7.Text = "Test Set Start Row";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 341);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 13);
            this.label6.TabIndex = 73;
            this.label6.Text = "Slope";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 315);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 13);
            this.label5.TabIndex = 72;
            this.label5.Text = "Momentum";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 289);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 13);
            this.label4.TabIndex = 71;
            this.label4.Text = "Learning Rate";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 149);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 13);
            this.label3.TabIndex = 70;
            this.label3.Text = "Hidden Layer Neurons";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 13);
            this.label2.TabIndex = 69;
            this.label2.Text = "Output Column End";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 68;
            this.label1.Text = "Input Columns End";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.splitContainer2);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(976, 568);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Run";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(3, 3);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.label55);
            this.splitContainer2.Panel1.Controls.Add(this.SmapeBox);
            this.splitContainer2.Panel1.Controls.Add(this.label53);
            this.splitContainer2.Panel1.Controls.Add(this.label52);
            this.splitContainer2.Panel1.Controls.Add(this.CMomentumBox);
            this.splitContainer2.Panel1.Controls.Add(this.CLrnRateBox);
            this.splitContainer2.Panel1.Controls.Add(this.label42);
            this.splitContainer2.Panel1.Controls.Add(this.label41);
            this.splitContainer2.Panel1.Controls.Add(this.RMSE2Box);
            this.splitContainer2.Panel1.Controls.Add(this.RSq2Box);
            this.splitContainer2.Panel1.Controls.Add(this.label39);
            this.splitContainer2.Panel1.Controls.Add(this.EpochMinRMSEBox);
            this.splitContainer2.Panel1.Controls.Add(this.label30);
            this.splitContainer2.Panel1.Controls.Add(this.label29);
            this.splitContainer2.Panel1.Controls.Add(this.label28);
            this.splitContainer2.Panel1.Controls.Add(this.label27);
            this.splitContainer2.Panel1.Controls.Add(this.testNOKBox);
            this.splitContainer2.Panel1.Controls.Add(this.testOKBox);
            this.splitContainer2.Panel1.Controls.Add(this.trnNOKBox);
            this.splitContainer2.Panel1.Controls.Add(this.trnOKBox);
            this.splitContainer2.Panel1.Controls.Add(this.StartBtn);
            this.splitContainer2.Panel1.Controls.Add(this.label26);
            this.splitContainer2.Panel1.Controls.Add(this.AvgTestErrBox);
            this.splitContainer2.Panel1.Controls.Add(this.label24);
            this.splitContainer2.Panel1.Controls.Add(this.RMSE1Box);
            this.splitContainer2.Panel1.Controls.Add(this.label23);
            this.splitContainer2.Panel1.Controls.Add(this.label21);
            this.splitContainer2.Panel1.Controls.Add(this.RSq1Box);
            this.splitContainer2.Panel1.Controls.Add(this.AvgTrainErrBox);
            this.splitContainer2.Panel1.Controls.Add(this.label22);
            this.splitContainer2.Panel1.Controls.Add(this.label20);
            this.splitContainer2.Panel1.Controls.Add(this.label19);
            this.splitContainer2.Panel1.Controls.Add(this.label18);
            this.splitContainer2.Panel1.Controls.Add(this.minErrBox);
            this.splitContainer2.Panel1.Controls.Add(this.EpochSMBox);
            this.splitContainer2.Panel1.Controls.Add(this.TimeBox);
            this.splitContainer2.Panel1.Controls.Add(this.EpochsBox);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer2.Size = new System.Drawing.Size(970, 562);
            this.splitContainer2.SplitterDistance = 264;
            this.splitContainer2.TabIndex = 0;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(11, 366);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(44, 13);
            this.label55.TabIndex = 146;
            this.label55.Text = "SMAPE";
            // 
            // SmapeBox
            // 
            this.SmapeBox.Location = new System.Drawing.Point(146, 363);
            this.SmapeBox.Name = "SmapeBox";
            this.SmapeBox.Size = new System.Drawing.Size(100, 20);
            this.SmapeBox.TabIndex = 145;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(12, 227);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(96, 13);
            this.label53.TabIndex = 144;
            this.label53.Text = "Current Momentum";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(11, 201);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(97, 13);
            this.label52.TabIndex = 143;
            this.label52.Text = "Current Learn Rate";
            // 
            // CMomentumBox
            // 
            this.CMomentumBox.Location = new System.Drawing.Point(146, 224);
            this.CMomentumBox.Name = "CMomentumBox";
            this.CMomentumBox.Size = new System.Drawing.Size(100, 20);
            this.CMomentumBox.TabIndex = 142;
            // 
            // CLrnRateBox
            // 
            this.CLrnRateBox.Location = new System.Drawing.Point(146, 198);
            this.CLrnRateBox.Name = "CLrnRateBox";
            this.CLrnRateBox.Size = new System.Drawing.Size(100, 20);
            this.CLrnRateBox.TabIndex = 141;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(12, 470);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(67, 13);
            this.label42.TabIndex = 140;
            this.label42.Text = "R-Squared 2";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(12, 418);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(47, 13);
            this.label41.TabIndex = 139;
            this.label41.Text = "RMSE 2";
            // 
            // RMSE2Box
            // 
            this.RMSE2Box.Location = new System.Drawing.Point(144, 415);
            this.RMSE2Box.Name = "RMSE2Box";
            this.RMSE2Box.Size = new System.Drawing.Size(100, 20);
            this.RMSE2Box.TabIndex = 138;
            // 
            // RSq2Box
            // 
            this.RSq2Box.Location = new System.Drawing.Point(144, 467);
            this.RSq2Box.Name = "RSq2Box";
            this.RSq2Box.Size = new System.Drawing.Size(100, 20);
            this.RSq2Box.TabIndex = 137;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(12, 175);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(127, 13);
            this.label39.TabIndex = 136;
            this.label39.Text = "Epochs since min. RMSE";
            // 
            // EpochMinRMSEBox
            // 
            this.EpochMinRMSEBox.Location = new System.Drawing.Point(146, 172);
            this.EpochMinRMSEBox.Name = "EpochMinRMSEBox";
            this.EpochMinRMSEBox.Size = new System.Drawing.Size(100, 20);
            this.EpochMinRMSEBox.TabIndex = 135;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(11, 340);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(79, 13);
            this.label30.TabIndex = 133;
            this.label30.Text = "Test Error NOK";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(11, 314);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(71, 13);
            this.label29.TabIndex = 132;
            this.label29.Text = "Test Error OK";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(11, 288);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(96, 13);
            this.label28.TabIndex = 131;
            this.label28.Text = "Training Error NOK";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(11, 262);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(88, 13);
            this.label27.TabIndex = 130;
            this.label27.Text = "Training Error OK";
            // 
            // testNOKBox
            // 
            this.testNOKBox.Location = new System.Drawing.Point(146, 337);
            this.testNOKBox.Name = "testNOKBox";
            this.testNOKBox.Size = new System.Drawing.Size(100, 20);
            this.testNOKBox.TabIndex = 129;
            // 
            // testOKBox
            // 
            this.testOKBox.Location = new System.Drawing.Point(146, 311);
            this.testOKBox.Name = "testOKBox";
            this.testOKBox.Size = new System.Drawing.Size(100, 20);
            this.testOKBox.TabIndex = 128;
            // 
            // trnNOKBox
            // 
            this.trnNOKBox.Location = new System.Drawing.Point(146, 285);
            this.trnNOKBox.Name = "trnNOKBox";
            this.trnNOKBox.Size = new System.Drawing.Size(100, 20);
            this.trnNOKBox.TabIndex = 127;
            // 
            // trnOKBox
            // 
            this.trnOKBox.Location = new System.Drawing.Point(146, 259);
            this.trnOKBox.Name = "trnOKBox";
            this.trnOKBox.Size = new System.Drawing.Size(100, 20);
            this.trnOKBox.TabIndex = 126;
            // 
            // StartBtn
            // 
            this.StartBtn.Location = new System.Drawing.Point(145, 503);
            this.StartBtn.Name = "StartBtn";
            this.StartBtn.Size = new System.Drawing.Size(99, 45);
            this.StartBtn.TabIndex = 125;
            this.StartBtn.Text = "Start/Stop";
            this.StartBtn.UseVisualStyleBackColor = true;
            this.StartBtn.Click += new System.EventHandler(this.StartStopBtn_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(12, 123);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(75, 13);
            this.label26.TabIndex = 124;
            this.label26.Text = "Avg Test Error";
            // 
            // AvgTestErrBox
            // 
            this.AvgTestErrBox.Location = new System.Drawing.Point(146, 120);
            this.AvgTestErrBox.Name = "AvgTestErrBox";
            this.AvgTestErrBox.Size = new System.Drawing.Size(100, 20);
            this.AvgTestErrBox.TabIndex = 123;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(12, 392);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(47, 13);
            this.label24.TabIndex = 122;
            this.label24.Text = "RMSE 1";
            // 
            // RMSE1Box
            // 
            this.RMSE1Box.Location = new System.Drawing.Point(145, 389);
            this.RMSE1Box.Name = "RMSE1Box";
            this.RMSE1Box.Size = new System.Drawing.Size(100, 20);
            this.RMSE1Box.TabIndex = 121;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(12, 444);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(67, 13);
            this.label23.TabIndex = 120;
            this.label23.Text = "R-Squared 1";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(12, 97);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(92, 13);
            this.label21.TabIndex = 119;
            this.label21.Text = "Avg Training Error";
            // 
            // RSq1Box
            // 
            this.RSq1Box.Location = new System.Drawing.Point(145, 441);
            this.RSq1Box.Name = "RSq1Box";
            this.RSq1Box.Size = new System.Drawing.Size(100, 20);
            this.RSq1Box.TabIndex = 118;
            // 
            // AvgTrainErrBox
            // 
            this.AvgTrainErrBox.Location = new System.Drawing.Point(145, 94);
            this.AvgTrainErrBox.Name = "AvgTrainErrBox";
            this.AvgTrainErrBox.Size = new System.Drawing.Size(100, 20);
            this.AvgTrainErrBox.TabIndex = 117;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(12, 71);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(93, 13);
            this.label22.TabIndex = 116;
            this.label22.Text = "Min. Training Error";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(12, 149);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(93, 13);
            this.label20.TabIndex = 115;
            this.label20.Text = "Epochs since min.";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(12, 45);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(71, 13);
            this.label19.TabIndex = 114;
            this.label19.Text = "Time Elapsed";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 19);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(43, 13);
            this.label18.TabIndex = 113;
            this.label18.Text = "Epochs";
            // 
            // minErrBox
            // 
            this.minErrBox.Location = new System.Drawing.Point(146, 68);
            this.minErrBox.Name = "minErrBox";
            this.minErrBox.Size = new System.Drawing.Size(100, 20);
            this.minErrBox.TabIndex = 112;
            // 
            // EpochSMBox
            // 
            this.EpochSMBox.Location = new System.Drawing.Point(145, 146);
            this.EpochSMBox.Name = "EpochSMBox";
            this.EpochSMBox.Size = new System.Drawing.Size(100, 20);
            this.EpochSMBox.TabIndex = 111;
            // 
            // TimeBox
            // 
            this.TimeBox.Location = new System.Drawing.Point(146, 42);
            this.TimeBox.Name = "TimeBox";
            this.TimeBox.Size = new System.Drawing.Size(100, 20);
            this.TimeBox.TabIndex = 110;
            // 
            // EpochsBox
            // 
            this.EpochsBox.Location = new System.Drawing.Point(146, 16);
            this.EpochsBox.Name = "EpochsBox";
            this.EpochsBox.Size = new System.Drawing.Size(100, 20);
            this.EpochsBox.TabIndex = 109;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.plotSurface2D1);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.plotSurface2D2);
            this.splitContainer3.Size = new System.Drawing.Size(702, 562);
            this.splitContainer3.SplitterDistance = 360;
            this.splitContainer3.TabIndex = 0;
            // 
            // plotSurface2D1
            // 
            this.plotSurface2D1.AutoScaleAutoGeneratedAxes = false;
            this.plotSurface2D1.AutoScaleTitle = false;
            this.plotSurface2D1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.plotSurface2D1.DateTimeToolTip = false;
            this.plotSurface2D1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.plotSurface2D1.Legend = null;
            this.plotSurface2D1.LegendZOrder = -1;
            this.plotSurface2D1.Location = new System.Drawing.Point(0, 0);
            this.plotSurface2D1.Name = "plotSurface2D1";
            this.plotSurface2D1.RightMenu = null;
            this.plotSurface2D1.ShowCoordinates = true;
            this.plotSurface2D1.Size = new System.Drawing.Size(702, 360);
            this.plotSurface2D1.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
            this.plotSurface2D1.TabIndex = 0;
            this.plotSurface2D1.Text = "plotSurface2D1";
            this.plotSurface2D1.Title = "";
            this.plotSurface2D1.TitleFont = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.plotSurface2D1.XAxis1 = null;
            this.plotSurface2D1.XAxis2 = null;
            this.plotSurface2D1.YAxis1 = null;
            this.plotSurface2D1.YAxis2 = null;
            // 
            // plotSurface2D2
            // 
            this.plotSurface2D2.AutoScaleAutoGeneratedAxes = false;
            this.plotSurface2D2.AutoScaleTitle = false;
            this.plotSurface2D2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.plotSurface2D2.DateTimeToolTip = false;
            this.plotSurface2D2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.plotSurface2D2.Legend = null;
            this.plotSurface2D2.LegendZOrder = -1;
            this.plotSurface2D2.Location = new System.Drawing.Point(0, 0);
            this.plotSurface2D2.Name = "plotSurface2D2";
            this.plotSurface2D2.RightMenu = null;
            this.plotSurface2D2.ShowCoordinates = true;
            this.plotSurface2D2.Size = new System.Drawing.Size(702, 198);
            this.plotSurface2D2.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
            this.plotSurface2D2.TabIndex = 0;
            this.plotSurface2D2.Text = "plotSurface2D2";
            this.plotSurface2D2.Title = "";
            this.plotSurface2D2.TitleFont = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.plotSurface2D2.XAxis1 = null;
            this.plotSurface2D2.XAxis2 = null;
            this.plotSurface2D2.YAxis1 = null;
            this.plotSurface2D2.YAxis2 = null;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.splitContainer5);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(976, 568);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Weights";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // splitContainer5
            // 
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.Location = new System.Drawing.Point(3, 3);
            this.splitContainer5.Name = "splitContainer5";
            this.splitContainer5.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.splitContainer6);
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.dataGridView7);
            this.splitContainer5.Size = new System.Drawing.Size(970, 562);
            this.splitContainer5.SplitterDistance = 380;
            this.splitContainer5.TabIndex = 0;
            // 
            // splitContainer6
            // 
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.Location = new System.Drawing.Point(0, 0);
            this.splitContainer6.Name = "splitContainer6";
            this.splitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.dataGridView3);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.dataGridView4);
            this.splitContainer6.Size = new System.Drawing.Size(970, 380);
            this.splitContainer6.SplitterDistance = 190;
            this.splitContainer6.TabIndex = 0;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView3.Location = new System.Drawing.Point(0, 0);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(970, 190);
            this.dataGridView3.TabIndex = 0;
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView4.Location = new System.Drawing.Point(0, 0);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(970, 186);
            this.dataGridView4.TabIndex = 0;
            // 
            // dataGridView7
            // 
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView7.Location = new System.Drawing.Point(0, 0);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.Size = new System.Drawing.Size(970, 178);
            this.dataGridView7.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.dataGridView5);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(976, 568);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Output Neurons";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // dataGridView5
            // 
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView5.Location = new System.Drawing.Point(3, 3);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.Size = new System.Drawing.Size(970, 562);
            this.dataGridView5.TabIndex = 0;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.dataGridView6);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(976, 568);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Test Results";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // dataGridView6
            // 
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView6.Location = new System.Drawing.Point(3, 3);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.Size = new System.Drawing.Size(970, 562);
            this.dataGridView6.TabIndex = 0;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.splitContainer7);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(976, 568);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "Training Graphs";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // splitContainer7
            // 
            this.splitContainer7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer7.Location = new System.Drawing.Point(3, 3);
            this.splitContainer7.Name = "splitContainer7";
            this.splitContainer7.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer7.Panel1
            // 
            this.splitContainer7.Panel1.Controls.Add(this.plotSurface2D5);
            // 
            // splitContainer7.Panel2
            // 
            this.splitContainer7.Panel2.Controls.Add(this.plotSurface2D6);
            this.splitContainer7.Size = new System.Drawing.Size(970, 562);
            this.splitContainer7.SplitterDistance = 281;
            this.splitContainer7.TabIndex = 0;
            // 
            // plotSurface2D5
            // 
            this.plotSurface2D5.AutoScaleAutoGeneratedAxes = false;
            this.plotSurface2D5.AutoScaleTitle = false;
            this.plotSurface2D5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.plotSurface2D5.DateTimeToolTip = false;
            this.plotSurface2D5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.plotSurface2D5.Legend = null;
            this.plotSurface2D5.LegendZOrder = -1;
            this.plotSurface2D5.Location = new System.Drawing.Point(0, 0);
            this.plotSurface2D5.Name = "plotSurface2D5";
            this.plotSurface2D5.RightMenu = null;
            this.plotSurface2D5.ShowCoordinates = true;
            this.plotSurface2D5.Size = new System.Drawing.Size(970, 281);
            this.plotSurface2D5.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
            this.plotSurface2D5.TabIndex = 0;
            this.plotSurface2D5.Text = "plotSurface2D5";
            this.plotSurface2D5.Title = "";
            this.plotSurface2D5.TitleFont = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.plotSurface2D5.XAxis1 = null;
            this.plotSurface2D5.XAxis2 = null;
            this.plotSurface2D5.YAxis1 = null;
            this.plotSurface2D5.YAxis2 = null;
            // 
            // plotSurface2D6
            // 
            this.plotSurface2D6.AutoScaleAutoGeneratedAxes = false;
            this.plotSurface2D6.AutoScaleTitle = false;
            this.plotSurface2D6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.plotSurface2D6.DateTimeToolTip = false;
            this.plotSurface2D6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.plotSurface2D6.Legend = null;
            this.plotSurface2D6.LegendZOrder = -1;
            this.plotSurface2D6.Location = new System.Drawing.Point(0, 0);
            this.plotSurface2D6.Name = "plotSurface2D6";
            this.plotSurface2D6.RightMenu = null;
            this.plotSurface2D6.ShowCoordinates = true;
            this.plotSurface2D6.Size = new System.Drawing.Size(970, 277);
            this.plotSurface2D6.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
            this.plotSurface2D6.TabIndex = 0;
            this.plotSurface2D6.Text = "plotSurface2D6";
            this.plotSurface2D6.Title = "";
            this.plotSurface2D6.TitleFont = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.plotSurface2D6.XAxis1 = null;
            this.plotSurface2D6.XAxis2 = null;
            this.plotSurface2D6.YAxis1 = null;
            this.plotSurface2D6.YAxis2 = null;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.splitContainer8);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(976, 568);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "Test Graphs";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // splitContainer8
            // 
            this.splitContainer8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer8.Location = new System.Drawing.Point(3, 3);
            this.splitContainer8.Name = "splitContainer8";
            this.splitContainer8.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer8.Panel1
            // 
            this.splitContainer8.Panel1.Controls.Add(this.plotSurface2D3);
            // 
            // splitContainer8.Panel2
            // 
            this.splitContainer8.Panel2.Controls.Add(this.plotSurface2D4);
            this.splitContainer8.Size = new System.Drawing.Size(970, 562);
            this.splitContainer8.SplitterDistance = 281;
            this.splitContainer8.TabIndex = 0;
            // 
            // plotSurface2D3
            // 
            this.plotSurface2D3.AutoScaleAutoGeneratedAxes = false;
            this.plotSurface2D3.AutoScaleTitle = false;
            this.plotSurface2D3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.plotSurface2D3.DateTimeToolTip = false;
            this.plotSurface2D3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.plotSurface2D3.Legend = null;
            this.plotSurface2D3.LegendZOrder = -1;
            this.plotSurface2D3.Location = new System.Drawing.Point(0, 0);
            this.plotSurface2D3.Name = "plotSurface2D3";
            this.plotSurface2D3.RightMenu = null;
            this.plotSurface2D3.ShowCoordinates = true;
            this.plotSurface2D3.Size = new System.Drawing.Size(970, 281);
            this.plotSurface2D3.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
            this.plotSurface2D3.TabIndex = 0;
            this.plotSurface2D3.Text = "plotSurface2D3";
            this.plotSurface2D3.Title = "";
            this.plotSurface2D3.TitleFont = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.plotSurface2D3.XAxis1 = null;
            this.plotSurface2D3.XAxis2 = null;
            this.plotSurface2D3.YAxis1 = null;
            this.plotSurface2D3.YAxis2 = null;
            // 
            // plotSurface2D4
            // 
            this.plotSurface2D4.AutoScaleAutoGeneratedAxes = false;
            this.plotSurface2D4.AutoScaleTitle = false;
            this.plotSurface2D4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.plotSurface2D4.DateTimeToolTip = false;
            this.plotSurface2D4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.plotSurface2D4.Legend = null;
            this.plotSurface2D4.LegendZOrder = -1;
            this.plotSurface2D4.Location = new System.Drawing.Point(0, 0);
            this.plotSurface2D4.Name = "plotSurface2D4";
            this.plotSurface2D4.RightMenu = null;
            this.plotSurface2D4.ShowCoordinates = true;
            this.plotSurface2D4.Size = new System.Drawing.Size(970, 277);
            this.plotSurface2D4.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
            this.plotSurface2D4.TabIndex = 0;
            this.plotSurface2D4.Text = "plotSurface2D4";
            this.plotSurface2D4.Title = "";
            this.plotSurface2D4.TitleFont = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.plotSurface2D4.XAxis1 = null;
            this.plotSurface2D4.XAxis2 = null;
            this.plotSurface2D4.YAxis1 = null;
            this.plotSurface2D4.YAxis2 = null;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.splitContainer4);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(976, 568);
            this.tabPage10.TabIndex = 9;
            this.tabPage10.Text = "Misc";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(3, 3);
            this.splitContainer4.Name = "splitContainer4";
            this.splitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.plotSurface2D7);
            this.splitContainer4.Size = new System.Drawing.Size(970, 562);
            this.splitContainer4.SplitterDistance = 281;
            this.splitContainer4.TabIndex = 0;
            // 
            // plotSurface2D7
            // 
            this.plotSurface2D7.AutoScaleAutoGeneratedAxes = false;
            this.plotSurface2D7.AutoScaleTitle = false;
            this.plotSurface2D7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.plotSurface2D7.DateTimeToolTip = false;
            this.plotSurface2D7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.plotSurface2D7.Legend = null;
            this.plotSurface2D7.LegendZOrder = -1;
            this.plotSurface2D7.Location = new System.Drawing.Point(0, 0);
            this.plotSurface2D7.Name = "plotSurface2D7";
            this.plotSurface2D7.RightMenu = null;
            this.plotSurface2D7.ShowCoordinates = true;
            this.plotSurface2D7.Size = new System.Drawing.Size(970, 281);
            this.plotSurface2D7.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
            this.plotSurface2D7.TabIndex = 0;
            this.plotSurface2D7.Text = "plotSurface2D7";
            this.plotSurface2D7.Title = "";
            this.plotSurface2D7.TitleFont = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.plotSurface2D7.XAxis1 = null;
            this.plotSurface2D7.XAxis2 = null;
            this.plotSurface2D7.YAxis1 = null;
            this.plotSurface2D7.YAxis2 = null;
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.plotSurface2D8);
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(976, 568);
            this.tabPage11.TabIndex = 10;
            this.tabPage11.Text = "Input Wt";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // plotSurface2D8
            // 
            this.plotSurface2D8.AutoScaleAutoGeneratedAxes = false;
            this.plotSurface2D8.AutoScaleTitle = false;
            this.plotSurface2D8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.plotSurface2D8.DateTimeToolTip = false;
            this.plotSurface2D8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.plotSurface2D8.Legend = null;
            this.plotSurface2D8.LegendZOrder = -1;
            this.plotSurface2D8.Location = new System.Drawing.Point(3, 3);
            this.plotSurface2D8.Name = "plotSurface2D8";
            this.plotSurface2D8.RightMenu = null;
            this.plotSurface2D8.ShowCoordinates = true;
            this.plotSurface2D8.Size = new System.Drawing.Size(970, 562);
            this.plotSurface2D8.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
            this.plotSurface2D8.TabIndex = 0;
            this.plotSurface2D8.Text = "plotSurface2D8";
            this.plotSurface2D8.Title = "";
            this.plotSurface2D8.TitleFont = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.plotSurface2D8.XAxis1 = null;
            this.plotSurface2D8.XAxis2 = null;
            this.plotSurface2D8.YAxis1 = null;
            this.plotSurface2D8.YAxis2 = null;
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.plotSurface2D9);
            this.tabPage12.Location = new System.Drawing.Point(4, 22);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(976, 568);
            this.tabPage12.TabIndex = 11;
            this.tabPage12.Text = "Out Wt";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // plotSurface2D9
            // 
            this.plotSurface2D9.AutoScaleAutoGeneratedAxes = false;
            this.plotSurface2D9.AutoScaleTitle = false;
            this.plotSurface2D9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.plotSurface2D9.DateTimeToolTip = false;
            this.plotSurface2D9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.plotSurface2D9.Legend = null;
            this.plotSurface2D9.LegendZOrder = -1;
            this.plotSurface2D9.Location = new System.Drawing.Point(3, 3);
            this.plotSurface2D9.Name = "plotSurface2D9";
            this.plotSurface2D9.RightMenu = null;
            this.plotSurface2D9.ShowCoordinates = true;
            this.plotSurface2D9.Size = new System.Drawing.Size(970, 562);
            this.plotSurface2D9.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
            this.plotSurface2D9.TabIndex = 0;
            this.plotSurface2D9.Text = "plotSurface2D9";
            this.plotSurface2D9.Title = "";
            this.plotSurface2D9.TitleFont = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.plotSurface2D9.XAxis1 = null;
            this.plotSurface2D9.XAxis2 = null;
            this.plotSurface2D9.YAxis1 = null;
            this.plotSurface2D9.YAxis2 = null;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(984, 94);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 714);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.statusStrip1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rain";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.Architecture.ResumeLayout(false);
            this.Architecture.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel2.ResumeLayout(false);
            this.splitContainer5.ResumeLayout(false);
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel2.ResumeLayout(false);
            this.splitContainer6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.splitContainer7.Panel1.ResumeLayout(false);
            this.splitContainer7.Panel2.ResumeLayout(false);
            this.splitContainer7.ResumeLayout(false);
            this.tabPage9.ResumeLayout(false);
            this.splitContainer8.Panel1.ResumeLayout(false);
            this.splitContainer8.Panel2.ResumeLayout(false);
            this.splitContainer8.ResumeLayout(false);
            this.tabPage10.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.ResumeLayout(false);
            this.tabPage11.ResumeLayout(false);
            this.tabPage12.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.ComponentModel.BackgroundWorker bgWorker1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.CheckBox ColNamesBox;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button LoadBtn;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox TempAlphaBox;
        private System.Windows.Forms.TextBox StartTempBox;
        private System.Windows.Forms.TextBox freqBox;
        private System.Windows.Forms.TextBox OutDirBox;
        private System.Windows.Forms.TextBox TrainEndBox;
        private System.Windows.Forms.TextBox EpochRMSEBox;
        private System.Windows.Forms.TextBox RSFBox;
        private System.Windows.Forms.TextBox OColStBox;
        private System.Windows.Forms.TextBox ErrThresBox;
        private System.Windows.Forms.TextBox HLayer2Box;
        private System.Windows.Forms.TextBox EpochMinBox;
        private System.Windows.Forms.TextBox TrainErrorBox;
        private System.Windows.Forms.TextBox TrainTimeBox;
        private System.Windows.Forms.TextBox IterationBox;
        private System.Windows.Forms.TextBox TotalRecBox;
        private System.Windows.Forms.TextBox TestEndBox;
        private System.Windows.Forms.TextBox TestStartBox;
        private System.Windows.Forms.TextBox AlphaBox;
        private System.Windows.Forms.TextBox MomentumBox;
        private System.Windows.Forms.TextBox LearnRateBox;
        private System.Windows.Forms.TextBox HLayerBox;
        private System.Windows.Forms.TextBox OColEndBox;
        private System.Windows.Forms.TextBox InColBox;
        private System.Windows.Forms.CheckBox SAchkBox;
        private System.Windows.Forms.CheckBox MTChkBox;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.ComboBox OutCboBox;
        private System.Windows.Forms.ComboBox Hid2CboBox;
        private System.Windows.Forms.ComboBox HidCboBox;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.CheckBox minPlotChkBox;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button DefaultBtn;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox Architecture;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox AlphaEMABox;
        private System.Windows.Forms.RadioButton NCRadBtn;
        private System.Windows.Forms.RadioButton EMARadBtn;
        private System.Windows.Forms.RadioButton WMARadBtn;
        private System.Windows.Forms.RadioButton NARXBtn;
        private System.Windows.Forms.TextBox OutStepsBox;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox InStepsBox;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox BetaBox;
        private System.Windows.Forms.RadioButton TDLRadBtn;
        private System.Windows.Forms.RadioButton RNNRadBtn;
        private System.Windows.Forms.RadioButton MLFFRadBtn;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.CheckBox Layers4Box;
        private System.Windows.Forms.CheckBox IntvChkBox;
        private System.Windows.Forms.CheckBox PartChkBox;
        private System.Windows.Forms.CheckBox RandChkBox;
        private System.Windows.Forms.CheckBox OutColChkBox;
        private System.Windows.Forms.Button ParamSubmitBtn;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox CMomentumBox;
        private System.Windows.Forms.TextBox CLrnRateBox;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox RMSE2Box;
        private System.Windows.Forms.TextBox RSq2Box;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox EpochMinRMSEBox;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox testNOKBox;
        private System.Windows.Forms.TextBox testOKBox;
        private System.Windows.Forms.TextBox trnNOKBox;
        private System.Windows.Forms.TextBox trnOKBox;
        private System.Windows.Forms.Button StartBtn;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox AvgTestErrBox;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox RMSE1Box;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox RSq1Box;
        private System.Windows.Forms.TextBox AvgTrainErrBox;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox minErrBox;
        private System.Windows.Forms.TextBox EpochSMBox;
        private System.Windows.Forms.TextBox TimeBox;
        private System.Windows.Forms.TextBox EpochsBox;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private NPlot.Windows.PlotSurface2D plotSurface2D1;
        private NPlot.Windows.PlotSurface2D plotSurface2D2;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.SplitContainer splitContainer7;
        private NPlot.Windows.PlotSurface2D plotSurface2D5;
        private NPlot.Windows.PlotSurface2D plotSurface2D6;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.SplitContainer splitContainer8;
        private NPlot.Windows.PlotSurface2D plotSurface2D3;
        private NPlot.Windows.PlotSurface2D plotSurface2D4;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private NPlot.Windows.PlotSurface2D plotSurface2D7;
        private System.Windows.Forms.TabPage tabPage11;
        private NPlot.Windows.PlotSurface2D plotSurface2D8;
        private System.Windows.Forms.TabPage tabPage12;
        private NPlot.Windows.PlotSurface2D plotSurface2D9;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox SmapeBox;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox TrainStartBox;

    }
}

