using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Timers;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
using System.Collections;
using System.IO;

namespace rain2
{
    public partial class Form1 : Form
    {

        #region *** Form Page ***

        public Form1()
        {
            InitializeComponent();
        }

        
        private void Form1_Load(object sender, EventArgs e)
        {
            InitializeTimer();
            ArrY = new ArrayList[2];
            ArrY[0] = new ArrayList();
            ArrY[1] = new ArrayList();
        }


        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // canceling current work
            needtostop = true;
            this.bgWorker1.CancelAsync();
        }


        private void tabControl1_TabIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex != 3)
                pagechange = true;
            else
                pagechange = false;
        }


        private void plotSurface2D1_MouseMove(object sender, MouseEventArgs e)
        {
            plotSurface2D1.Refresh();
        }


        private void toolStripStatusLabel1_MouseEnter(object sender, EventArgs e)
        {
            statusStrip1.Text = readCnt.ToString();
        }


        #endregion
        

        #region *** Load Page ***


        private void LoadBtn_Click(object sender, EventArgs e)
        {
            inData = null;

            if (openFileDialog == null)
                openFileDialog = new OpenFileDialog();

            if (openFileDialog.ShowDialog() == DialogResult.OK)
                readFile(openFileDialog.FileName);
            else
            {
                dataGridView1.DataSource = null;
                dataGridView2.DataSource = null;
                return;
            }

            TotalRecBox.Text = (readCnt-firstRec).ToString();
            Form1.ActiveForm.Text = openFileDialog.FileName + " - Rain Prediction";

            if (readCnt > 0)
            {
                if (!DisplayData())
                    return;
                CalMinMax();
                DisplayMaxMin();
                UpdateTextBox();
                pStatus = Status.Loaded;
                toolStripStatusLabel2.Text = pStatus.ToString();
            }
            else
            {
                if (fileerror)
                    MessageBox.Show("File not opened. Remember to close the file if another process is using it.");
                else
                    MessageBox.Show("No records found. Remember to select checkbox\nif first row contains Column header names.");
                pStatus = Status.NotLoaded;
                toolStripStatusLabel2.Text = pStatus.ToString();
            }
           
        }

    #endregion


        #region *** Parameters Page ***


        private void ReadTextBoxes()
        {
            inCol           = int.Parse(InColBox.Text);
            outColStart     = int.Parse(OColStBox.Text);
            outColEnd       = int.Parse(OColEndBox.Text);
            learningRate    = double.Parse(LearnRateBox.Text);
            momentum        = double.Parse(MomentumBox.Text);
            hiddenNodes     = int.Parse(HLayerBox.Text);
            Alpha           = double.Parse(AlphaBox.Text);
            Beta            = double.Parse(BetaBox.Text);
            delta           = int.Parse(InStepsBox.Text);
            epsilon         = int.Parse(OutStepsBox.Text);
            alphacoeff      = double.Parse(AlphaEMABox.Text);
            rangeSF         = double.Parse(RSFBox.Text);
            actualStart     = int.Parse(TrainStartBox.Text);
            trainSetEnd     = int.Parse(TrainEndBox.Text);
            testSetStart    = int.Parse(TestStartBox.Text);
            testSetEnd      = int.Parse(TestEndBox.Text);
            iterations      = int.Parse(IterationBox.Text);
            errLimit        = double.Parse(TrainErrorBox.Text);
            trainTime       = int.Parse(TrainTimeBox.Text);
            epochFrMin      = int.Parse(EpochMinBox.Text);
            epochFrMinRMSE  = int.Parse(EpochRMSEBox.Text);
            epochAftMinRMSE = int.Parse(EpochMinRMSEBox.Text);
            errThresh       = double.Parse(ErrThresBox.Text);
            frequency       = int.Parse(freqBox.Text);

            trainSetStart   = actualStart - 1;                  // array index start from zero for 1st row
            trainCnt        = trainSetEnd - trainSetStart + 1;  // no. of training records
            testCnt         = testSetEnd - testSetStart;        // no. of test records
            outNodes        = outColEnd - outColStart + 1;      // no . of output nodes
            timer1.Interval = frequency;                        // update timer interrupt

            if (Layers4Box.Checked)
            {
                hiddenNodes2 = int.Parse(HLayer2Box.Text);
                fourlayer = (hiddenNodes > 0)? true : false;
            }
            else
            {
                hiddenNodes2 = 0;
                fourlayer = false;
            }

            if (SAchkBox.Checked)
            {
                sanneal = true;
                StartTempBox.Enabled = true;
                TempAlphaBox.Enabled = true;
                startTemp = int.Parse(StartTempBox.Text);
                alphaTemp = double.Parse(TempAlphaBox.Text);
            }

            // process Activation Function section (sigmiod = 0, bipolarsigmoid = 1, tanh = 2
            hidActF  = HidCboBox.SelectedIndex;
            hid2ActF = Hid2CboBox.SelectedIndex;
            outActF  = OutCboBox.SelectedIndex;
            if (HidCboBox.SelectedIndex  == -1) hidActF  = 0;
            if (Hid2CboBox.SelectedIndex == -1) hid2ActF = 0;
            if (OutCboBox.SelectedIndex  == -1) outActF  = 0;
            bipolar = (hidActF == 1 || hid2ActF == 1 || outActF == 1)? true : false;

        }

        
        private void UpdateTextBox()
        {
            LearnRateBox.Text       = learningRate.ToString();
            MomentumBox.Text        = momentum.ToString();
            AlphaBox.Text           = Alpha.ToString();
            BetaBox.Text            = Beta.ToString();
            AlphaEMABox.Text        = alphacoeff.ToString();
            InStepsBox.Text         = delta.ToString();
            OutStepsBox.Text        = epsilon.ToString();
            RSFBox.Text             = rangeSF.ToString();
            TotalRecBox.Text        = readCnt.ToString();
            OutDirBox.Text          = outDir;
            IterationBox.Text       = iterations.ToString();
            TrainStartBox.Text      = (firstRec+1).ToString();     // default to firstRec
            TrainErrorBox.Text      = errLimit.ToString();
            TrainTimeBox.Text       = trainTime.ToString();
            EpochMinBox.Text        = epochFrMin.ToString();
            EpochRMSEBox.Text       = epochFrMinRMSE.ToString();
            EpochMinRMSEBox.Text    = epochAftMinRMSE.ToString();
            ErrThresBox.Text        = errThresh.ToString();
            freqBox.Text            = frequency.ToString();
            StartTempBox.Text       = startTemp.ToString();
            TempAlphaBox.Text       = alphaTemp.ToString();

            HidCboBox.SelectedIndex = 0;
            Hid2CboBox.SelectedIndex= 0;
            OutCboBox.SelectedIndex = 0;

            //Set default radio button
            MLFFRadBtn.Checked   = true;
            NCRadBtn.Checked     = true;
            BetaBox.Enabled      = false;
            AlphaEMABox.Enabled  = false;
            InStepsBox.Enabled   = false;
            OutStepsBox.Enabled  = false;
            HLayer2Box.Enabled   = false;
            TotalRecBox.Enabled  = false;
            Hid2CboBox.Enabled   = false;
            StartTempBox.Enabled = false;
            TempAlphaBox.Enabled = false;
        }


        private void DefaultBtn_Click(object sender, EventArgs e)
        {
            if (readCnt > 0)
            {
                inCol           = attrCnt - 1;
                outColStart     = inCol + 1;
                outColEnd       = attrCnt;
                hiddenNodes     = Convert.ToInt32(inCol / 2 + Math.Sqrt(inCol));
                hiddenNodes2    = hiddenNodes;
                trainSetStart   = firstRec;
                actualStart     = trainSetStart + 1;
                testSetStart    = Convert.ToInt32(0.8 * readCnt);
                testSetEnd      = readCnt;
                trainSetEnd     = testSetStart - 1;
                frequency       = 1000;
                
                HidCboBox.SelectedIndex     = 0;
                Hid2CboBox.SelectedIndex    = 0;
                OutCboBox.SelectedIndex     = 0;
                OutDirBox.Text              = outDir;
                InColBox.Text               = inCol.ToString();
                OColStBox.Text              = outColStart.ToString();
                OColEndBox.Text             = outColEnd.ToString();
                HLayerBox.Text              = hiddenNodes.ToString();
                HLayer2Box.Text             = hiddenNodes2.ToString();
                TrainStartBox.Text          = actualStart.ToString();
                TrainEndBox.Text            = trainSetEnd.ToString();
                TestStartBox.Text           = testSetStart.ToString();
                TestEndBox.Text             = testSetEnd.ToString();
                freqBox.Text                = frequency.ToString();

                DefaultBtn.Enabled  = true;
                MLFFRadBtn.Checked  = true;
                NCRadBtn.Checked    = true;
            }
            else
            {
                MessageBox.Show("No records. Pls load csv file.");
                DefaultBtn.Enabled = false;
            }
        }


        private void TrainEndBox_TextChanged(object sender, EventArgs e)
        {
            if (TrainEndBox.Text != "")
                trainSetEnd = int.Parse(TrainEndBox.Text);
            if (TestStartBox.Text != "")
                testSetStart = int.Parse(TestStartBox.Text);

            if (testSetStart <= trainSetEnd)
            {
                testSetStart = trainSetEnd + 1;
                TestStartBox.Text = testSetStart.ToString();
                TestStartBox.ForeColor = Color.Red;
            }
        }


        private void TestStartBox_TextChanged(object sender, EventArgs e)
        {
            if (TestStartBox.ForeColor.Equals(Color.Red))
                TestStartBox.ForeColor = Color.Black;
        }


        private void Layers4Box_CheckedChanged(object sender, EventArgs e)
        {
            HLayer2Box.Enabled = Hid2CboBox.Enabled = Layers4Box.Checked ? true : false;
        }


        private void RNNRadBtn_CheckedChanged(object sender, EventArgs e)
        {
            BetaBox.Enabled = RNNRadBtn.Checked ? true : false;
        }


        private void TDLRadBtn_CheckedChanged(object sender, EventArgs e)
        {
            InStepsBox.Enabled = TDLRadBtn.Checked ? true : false;
        }


        private void NARXBtn_CheckedChanged(object sender, EventArgs e)
        {
            InStepsBox.Enabled = OutStepsBox.Enabled = NARXBtn.Checked ? true : false;
        }


        private void EMARadBtn_CheckedChanged(object sender, EventArgs e)
        {
            AlphaEMABox.Enabled = EMARadBtn.Checked ? true : false;
        }


        private void SAchkBox_CheckedChanged(object sender, EventArgs e)
        {
            sanneal = SAchkBox.Checked ? true : false;
            StartTempBox.Enabled  = TempAlphaBox.Enabled = sanneal ? true : false;
        }


        private void OutDirBox_MouseClick(object sender, MouseEventArgs e)
        {
            OpenFileDialog openFileDialog = null;

            if (openFileDialog == null)
                openFileDialog = new OpenFileDialog();

            if (openFileDialog.ShowDialog() == DialogResult.OK)
                outDir = Path.GetDirectoryName(openFileDialog.FileName);

            OutDirBox.Text = outDir;
        }
        
        
        private void ParamSubmitBtn_Click(object sender, EventArgs e)
        {
            currEpoch = 0;
            
            if (OutColChkBox.Checked && (readCnt > 0))
            {
                inCol           = attrCnt - 1;
                outColStart     = inCol + 1;
                outColEnd       = attrCnt;
                hiddenNodes     = Convert.ToInt32(inCol / 2 + Math.Sqrt(inCol));
                hiddenNodes2    = hiddenNodes;
                InColBox.Text   = inCol.ToString();
                OColStBox.Text  = outColStart.ToString();
                OColEndBox.Text = outColEnd.ToString();
                HLayerBox.Text  = hiddenNodes.ToString();
                HLayer2Box.Text = hiddenNodes2.ToString();
            }
            
            if (PartChkBox.Checked && (readCnt>0))
            {
                testSetStart       = Convert.ToInt32(0.7 * readCnt);
                testSetEnd         = Convert.ToInt32(0.9 * readCnt);
                TestStartBox.Text  = testSetStart.ToString();
                TestEndBox.Text    = testSetEnd.ToString();
            }
            
            if (InColBox.Text.Equals("")        ||
                OColEndBox.Text.Equals("")      ||
                LearnRateBox.Text.Equals("")    ||
                MomentumBox.Text.Equals("")     ||
                HLayerBox.Text.Equals("")       ||
                AlphaBox.Text.Equals("")        ||
                BetaBox.Text.Equals("")         ||
                AlphaEMABox.Text.Equals("")     ||
                InStepsBox.Text.Equals("")      ||
                OutStepsBox.Text.Equals("")     ||
                RSFBox.Text.Equals("")          ||
                TrainEndBox.Text.Equals("")     ||
                TestStartBox.Text.Equals("")    ||
                TestEndBox.Text.Equals("")      ||
                IterationBox.Text.Equals("")    ||
                TrainErrorBox.Text.Equals("")   ||
                TrainTimeBox.Text.Equals("")    ||
                EpochMinBox.Text.Equals("")     ||
                EpochRMSEBox.Text.Equals("")    ||
                (SAchkBox.Checked && 
                  (StartTempBox.Text.Equals("") || 
                   TempAlphaBox.Text.Equals("")))
                )
                MessageBox.Show("Settings incomplete.");
            else
            {
                ReadTextBoxes();
                if (inCol > attrCnt)
                    MessageBox.Show("Input data may have changed. Check settings again." +
                        " Or press the default button if unsure.");
                else
                {
                    CalMinMax();
                    MessageBox.Show("Ok");
                    pStatus = Status.SettingOK;
                    toolStripStatusLabel2.Text = pStatus.ToString();
                }
            }
        }

        
        #endregion


        #region *** Run Page ***

        
        private void InitTextBoxes()
        {
            EpochsBox.Text = "";
            TimeBox.Text = "";
            EpochSMBox.Text = "";
            AvgTrainErrBox.Text = "";
            AvgTestErrBox.Text = "";
            minErrBox.Text = "";
            RMSE1Box.Text = "";
            RSq1Box.Text = "";
            RMSE2Box.Text = "";
            RSq2Box.Text = "";

            currEpoch       = 0;
            currTestErr     = 0;
            epochAftMinRMSE = 0;
            trnErrOK        = 0;
            trnErrNOK       = 0;
            testErrOK       = 0;
            testErrNOK      = 0;
            minErr          = 999;
            //minTestErr      = 999;
            minTestRMSE     = 999;

            if (outNodes == 1)
            {
                plotSurface2D4.Clear();
                plotSurface2D6.Clear();
            }
        }
        
        
        private void StartStopBtn_Click(object sender, EventArgs e)
        {
            if (pStatus.Equals(Status.SettingOK) ||
                pStatus.Equals(Status.Running)   ||
                pStatus.Equals(Status.Stopped))
            {
                if (!bgWorker1.IsBusy)
                {
                    // starting new work - resest objects
                    InitTextBoxes();

                    needtostop = false;
                    pStatus = Status.Running;
                    toolStripStatusLabel2.Text = pStatus.ToString();

                    // start the worker
                    this.bgWorker1.RunWorkerAsync();
                }
                else
                {
                    needtostop = true;
                    pStatus = Status.Stopping;
                    toolStripStatusLabel2.Text = pStatus.ToString();
                    // canceling current work
                    this.bgWorker1.CancelAsync();
                    DisplayResultsOutNeurons();
                }
            }
            else
            {
                MessageBox.Show("Remember to update parameters or press submit button again.");
            }
        }


        private void bgWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            if (bgWorker1.CancellationPending)
            {
                // user canceled
                e.Cancel = true;
                this.richTextBox1.AppendText
                    ("\r\nCancel requested.\n");
                return;
            }
            else
            {
                PreProcess();
                stopWatch.Start();
                SearchSoln();
                stopTime(stopWatch);
            }
        }


        private void bgWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {

        }


        private void bgWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!e.Cancelled && (e.Error == null))
            {
                double trainerr   = double.Parse(AvgTrainErrBox.Text);
                double testerr    = double.Parse(AvgTestErrBox.Text);
                double rsq        = double.Parse(RSq1Box.Text);
                double pcttestok  = Math.Round(Math.Abs(testErrOK/(testErrOK + testErrNOK)*100), 2);
                double pcttestnok = Math.Round((100 - pcttestok), 2);
                string rnnstr     = "", mystr = "";

                pStatus = Status.Stopped;
                toolStripStatusLabel2.Text = pStatus.ToString();

                if (RNNRadBtn.Checked)
                    rnnstr = "RNN";
                mystr = string.Format("{0}  {1} Completed. R-Sq = {2} Error: Train = {3} Test = {4}. Test OK = {5}% NOK = {6}%. {7}",
                    DateTime.Now, rnnstr, rsq, trainerr, testerr, pcttestok, pcttestnok, e.Result);
                for (int j = 0; j < outNodes; j++)
                    mystr += string.Format(" rmse{0} = {1}", j, Math.Round(rmse[j],6));
                this.richTextBox1.AppendText(mystr + "\n");

                DisplayResults();
                if (fourlayer)
                    DisplayResults2();
                else
                    dataGridView4.DataSource = null;

                DisplayResults3();
                DisplayResultsOutNeurons();
                DisplayResultsTest();

                PlotWavelet3();     // test Set plot for output node 1
                PlotWavelet5();     // training Set plot for output node 1
                PlotWavelet7(); 
                PlotWavelet8();     // connection weights for input-hidden
                PlotWavelet9();     // connection weights for hidden-output
                if (outNodes > 1)
                {
                    PlotWavelet4();
                    PlotWavelet6();
                }
                else
                {
                    this.plotSurface2D4.Clear();
                    this.plotSurface2D6.Clear();
                }
            }
            else
            {
                this.richTextBox1.AppendText
                    ("\r\nWork completed abnormally (either cancel or error).\n");
            }
        }

        #endregion





    }
}