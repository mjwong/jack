using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Collections;

namespace rain2
{
    public partial class Form1
    {
        public void stopTime(Stopwatch stopWatch)
        {
            TimeSpan ts;
            String showtime = null;


            // Get the elapsed time as a TimeSpan value.
            stopWatch.Stop();
            ts = stopWatch.Elapsed;
            stopWatch.Reset();

            // Format and display the TimeSpan value.
            showtime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}", ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10);
            SetTextTimeBox(showtime);
        }
    }
}
