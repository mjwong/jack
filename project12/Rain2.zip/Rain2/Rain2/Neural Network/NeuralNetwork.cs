﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Reflection;

namespace rain2
{
    // Implements a 3-Layer neural network with one input layer, one hidden layer, and one output layer
    public class NeuralNetwork : BaseObject
    {
        public NeuralNetworkLayer InputLayer;
        public NeuralNetworkLayer HiddenLayer;
        public NeuralNetworkLayer HiddenLayer2;
        public NeuralNetworkLayer OutputLayer;

        private int INT_MAX = 999;
        private double maxval   = 0;    // max. output node value
        public int inDataNodes = 0;    // no. of orginal input nodes (read from data), exclude feedback elements
        

        public NeuralNetwork() 
        {
            InputLayer      = new NeuralNetworkLayer();
            HiddenLayer     = new NeuralNetworkLayer();
            HiddenLayer2    = new NeuralNetworkLayer();
            OutputLayer     = new NeuralNetworkLayer();
        }


        /////////////////////////////////////////////////////////////////////////////////////////////////
        // NeuralNetwork Class Members
        /////////////////////////////////////////////////////////////////////////////////////////////////

        public void Initialize(int nNodesInput,   int nNodesHidden, 
                                int nNodesHidden2, int nNodesOutput, bool twohiddenlayer)
        {
            if (twohiddenlayer)
            {
                InputLayer.NumberOfNodes = nNodesInput;
                InputLayer.NumberOfChildNodes = nNodesHidden;
                InputLayer.NumberOfParentNodes = 0;
                InputLayer.Initialize(nNodesInput, null, HiddenLayer);
                InputLayer.RandomizeWeights();

                HiddenLayer.NumberOfNodes = nNodesHidden;
                HiddenLayer.NumberOfChildNodes = nNodesHidden2;
                HiddenLayer.NumberOfParentNodes = nNodesInput;
                HiddenLayer.Initialize(nNodesHidden, InputLayer, HiddenLayer2);
                HiddenLayer.RandomizeWeights();

                HiddenLayer2.NumberOfNodes = nNodesHidden2;
                HiddenLayer2.NumberOfChildNodes = nNodesOutput;
                HiddenLayer2.NumberOfParentNodes = nNodesHidden;
                HiddenLayer2.Initialize(nNodesHidden2, HiddenLayer, OutputLayer);
                HiddenLayer2.RandomizeWeights();

                OutputLayer.NumberOfNodes = nNodesOutput;
                OutputLayer.NumberOfChildNodes = 0;
                OutputLayer.NumberOfParentNodes = nNodesHidden2;
                OutputLayer.Initialize(nNodesOutput, HiddenLayer2, null);
            }
            else
            {
                InputLayer.NumberOfNodes = nNodesInput;
                InputLayer.NumberOfChildNodes = nNodesHidden;
                InputLayer.NumberOfParentNodes = 0;
                InputLayer.Initialize(nNodesInput, null, HiddenLayer);
                InputLayer.RandomizeWeights();

                HiddenLayer.NumberOfNodes = nNodesHidden;
                HiddenLayer.NumberOfChildNodes = nNodesOutput;
                HiddenLayer.NumberOfParentNodes = nNodesInput;
                HiddenLayer.Initialize(nNodesHidden, InputLayer, OutputLayer);
                HiddenLayer.RandomizeWeights();

                OutputLayer.NumberOfNodes = nNodesOutput;
                OutputLayer.NumberOfChildNodes = 0;
                OutputLayer.NumberOfParentNodes = nNodesHidden;
                OutputLayer.Initialize(nNodesOutput, HiddenLayer, null);	
            }
        }

       
        public void	SetInput(int i, double value)
        {
	        if((i>=0) && (i<InputLayer.NumberOfNodes))
	        {
		        InputLayer.NeuronValues[i] = value;
	        }
        }

        
        public double GetOutput(int i)
        {
	        if((i>=0) && (i<OutputLayer.NumberOfNodes))
	        {
		        return OutputLayer.NeuronValues[i];
	        }

	        return (double) INT_MAX; // to indicate an error
        }

        
        public void SetDesiredOutput(int i, double value)
        {
	        if((i>=0) && (i<OutputLayer.NumberOfNodes))
	        {
		        OutputLayer.DesiredValues[i] = value;
	        }
        }


        public void ShiftInput(int delta)
        {
            double value;
            
            for (int i = delta - 1; i >= 0; i--)
            {
                for (int j = 0; j < inDataNodes; j++)
                {
                    value = InputLayer.NeuronValues[i*inDataNodes + j];
                    SetInput((i+1) * inDataNodes + j, value); 
                }
            }
        }


        public void ShiftOutput(int epsilon)
        {
            double value;
            int outNodes = OutputLayer.NumberOfNodes;
            int startpos = InputLayer.NumberOfNodes - outNodes * epsilon;

            for (int i = epsilon - 2; i >= 0; i--)
            {
                // shift input elements order u from time (t-u) to (t-u-1)
                for (int j = 0; j < outNodes; j++)
                {
                    value = InputLayer.NeuronValues[startpos + outNodes * i + j];
                    SetInput(startpos + outNodes * (i + 1) + j, value);
                }
            }

            // shift output into first set (order 0) of input elements at time t
            // array position is after all the input nodes
            for (int j = 0; j < outNodes; j++)
            {
                value = OutputLayer.NeuronValues[j];
                SetInput(startpos + j, value);
            }
        }


        public void ApplyMACoeffToInput(double [] coeff, int delta)
        {
            int node = 0;
            double value = 0.0f;

            for (int i = 0; i < delta; i++)
                for (int j = 0; j < inDataNodes; j++)
                {
                    node = i * inDataNodes + j;
                    value = coeff[i] * InputLayer.NeuronValues[node];
                    SetInput(node, value);
                }
        }


        public void ApplyMACoeffToOutput(double[] coeff, int epsilon)
        {
            int node     = 0;
            int outNodes = OutputLayer.NumberOfNodes;
            int startpos = InputLayer.NumberOfNodes - outNodes * epsilon;
            double value = 0.0f;

            for (int i = 0; i < epsilon; i++)
                for (int j = 0; j < outNodes; j++)
                {
                    node = startpos + i * outNodes + j;
                    value = coeff[i] * InputLayer.NeuronValues[node];
                    SetInput(node, value);
                }
        }


        public void ClearInputDelay(int delta)
        {
            for (int i = delta; i > 0; i--)
                for (int j = 0; j < inDataNodes; j++)
                    SetInput(i * inDataNodes + j, 0.0f);
        }


        public void ClearOutputDelay(int epsilon)
        {
            int outNodes = OutputLayer.NumberOfNodes;
            int startpos = InputLayer.NumberOfNodes - outNodes * epsilon;

            for (int i = epsilon - 1; i >= 0; i--)
                for (int j = 0; j < outNodes; j++)
                    SetInput(startpos + outNodes * i + j, 0.0f);
        }

        
        public void FeedForward(bool twohiddenlayer)
        {
            if (twohiddenlayer)
            {
                InputLayer.CalculateNeuronValues();
                HiddenLayer.CalculateNeuronValues();
                HiddenLayer2.CalculateNeuronValues();
                OutputLayer.CalculateNeuronValues();
            }
            else
            {
                InputLayer.CalculateNeuronValues();
                HiddenLayer.CalculateNeuronValues();
                OutputLayer.CalculateNeuronValues();
            }
        }


        public void BackPropagate(bool twohiddenlayer)
        {
            if (twohiddenlayer)
            {
                OutputLayer.CalculateErrors();

                HiddenLayer2.CalculateErrors();
                HiddenLayer2.AdjustWeights();

                HiddenLayer.CalculateErrors();
                HiddenLayer.AdjustWeights();

                InputLayer.AdjustWeights();
            }
            else
            {
                OutputLayer.CalculateErrors();
                HiddenLayer.CalculateErrors();

                HiddenLayer.AdjustWeights();
                InputLayer.AdjustWeights();
            }
        }

        
        public int GetMaxOutputID()
        {
	        int		i, id;

	        maxval = OutputLayer.NeuronValues[0];
	        id = 0;

	        for(i=1; i<OutputLayer.NumberOfNodes; i++)
	        {
		        if(OutputLayer.NeuronValues[i] > maxval)
		        {
			        maxval = OutputLayer.NeuronValues[i];
			        id = i;
		        }
	        }

	        return id;
        }


        public double CalculateError()
        {
	        int		i;
	        double	error = 0;

	        for(i=0; i<OutputLayer.NumberOfNodes; i++)
	        {
		        error += Math.Pow(OutputLayer.NeuronValues[i] - OutputLayer.DesiredValues[i], 2);
	        }

	        error = error / OutputLayer.NumberOfNodes;

	        return error;
        }


        public void SetLearningRate(double rate)
        {
            InputLayer.LearningRate     = rate;
            HiddenLayer.LearningRate    = rate;
            HiddenLayer2.LearningRate   = rate;
            OutputLayer.LearningRate    = rate;
        }
       
        
        public void SetLearningRate(double irate, double hrate, double h2rate, double orate)
        {
	        InputLayer.LearningRate     = irate;
	        HiddenLayer.LearningRate    = hrate;
            HiddenLayer2.LearningRate   = h2rate;
	        OutputLayer.LearningRate    = orate;
        } 
 
       
        public void	SetActiveFunct(int hidAF, int hid2AF, int outAF)
        {
            HiddenLayer.ActFunc     = hidAF;
            HiddenLayer2.ActFunc    = hid2AF;
            OutputLayer.ActFunc     = outAF;
        }


        public void	SetMomentum(double factor)
        {
	        InputLayer.MomentumFactor   = factor;
	        HiddenLayer.MomentumFactor  = factor;
	        OutputLayer.MomentumFactor  = factor;
        }


        public void SetMomentum(double ifactor, double hfactor, 
            double h2factor, double ofactor)
        {
            InputLayer.MomentumFactor   = ifactor;
            HiddenLayer.MomentumFactor  = hfactor;
            HiddenLayer2.MomentumFactor = h2factor;
            OutputLayer.MomentumFactor  = ofactor;
        }


        public void SetAlpha(double Alpha)
        {
            InputLayer.Alpha    = Alpha;
            HiddenLayer.Alpha   = Alpha;
            HiddenLayer2.Alpha  = Alpha;
            OutputLayer.Alpha   = Alpha;
        }


        public void SetBeta(double Beta)
        {
            if (Beta > 1 || Beta < 0)
                Beta = 0.5;
            HiddenLayer.Beta    = Beta;
            HiddenLayer2.Beta   = Beta;
            if (Beta > 0)
            {
                HiddenLayer.rnn  = true;
                HiddenLayer2.rnn = true;
            }
            else
            {
                HiddenLayer.rnn  = false;
                HiddenLayer2.rnn = false;
            }

        }   


        public void DumpData(String outdir, String filename)
        {
            StreamWriter f  = null;
	        int		i, j, index = 0;

            try {
                f = new StreamWriter(outdir + @"\out.tmp");
            }
            catch (Exception e) {
                throw new Exception("Failed to create a stream writer with error:"
                    + "\n" + e.Message + "\n");
            }
        	
	        f.WriteLine("--------------------------------------------------------");
            f.WriteLine("Input Layer");
            f.WriteLine("--------------------------------------------------------");
            f.WriteLine("\nNode Values:\n");
	        for(i=0; i<InputLayer.NumberOfNodes; i++)
                f.WriteLine("({0}) = {1}", i, InputLayer.NeuronValues[i]);
            f.WriteLine("\nWeights:\n");
	        for(i=0; i<InputLayer.NumberOfNodes; i++)
		        for(j=0; j<InputLayer.NumberOfChildNodes; j++)
                    f.WriteLine("({0}, {1}) = {2}", i, j, InputLayer.Weights[i,j]);
            f.WriteLine("\nBias Weights:\n");
	        for(j=0; j<InputLayer.NumberOfChildNodes; j++)
                f.WriteLine("({0}) = {1}\n", j, InputLayer.BiasWeights[j]);

            f.WriteLine("\n--------------------------------------------------------");
            f.WriteLine("Hidden Layer");
            f.WriteLine("--------------------------------------------------------");
            f.WriteLine("\nWeights:\n");
	        for(i=0; i<HiddenLayer.NumberOfNodes; i++)
		        for(j=0; j<HiddenLayer.NumberOfChildNodes; j++)
                    f.WriteLine("({0}, {1}) = {2}", i, j, HiddenLayer.Weights[i, j]);
            
            f.WriteLine("\nBias Weights:\n");
	        for(j=0; j<HiddenLayer.NumberOfChildNodes; j++)
                f.WriteLine("({0}) = {1}", j, HiddenLayer.BiasWeights[j]);

            f.WriteLine("\nNode Values:\n");
            for (j = 0; j < HiddenLayer.NumberOfNodes; j++)
                f.WriteLine("({0}) = {1}\n", j, HiddenLayer.NeuronValues[j]);
            
	        f.WriteLine("--------------------------------------------------------");
	        f.WriteLine("Output Layer");
	        f.WriteLine("--------------------------------------------------------\n");
            f.WriteLine("Node Values:\n");
	        for(i=0; i<OutputLayer.NumberOfNodes; i++)
                f.WriteLine("({0}) = {1}\n", i, OutputLayer.NeuronValues[i]);

            f.WriteLine("Desired Values:\n");
            for (i = 0; i < OutputLayer.NumberOfNodes; i++)
                f.WriteLine("({0}) = {1}\n", i, OutputLayer.DesiredValues[i]);

            f.WriteLine("Error = {0:F6}", CalculateError());

            f.Close();

            string path = outdir + @"\" + filename;
            string[] origfile = filename.Split('.');
            string filen = filename;
            while (File.Exists(path))
            {
                // if file exists then increment trailing index;
                if (filen.Contains("."))
                    filen = origfile[0] + index++ + '.' + origfile[1];
                else
                    filen = origfile[0] + index++;

                path = outdir + @"\" + filen;
            }

            // Try to copy the file.
            File.Copy(outdir + @"\out.tmp", path, true);

        }

    };

}
