﻿using System;
using System.Collections.Generic;
using System.Text;

namespace rain2
{
    /////////////////////////////////////////////////////////////////////////////////////////////////
    // NeuralNetworkLayer Class
    /////////////////////////////////////////////////////////////////////////////////////////////////

    public class NeuralNetworkLayer
    {
	    public int		 NumberOfNodes;
	    public int		 NumberOfChildNodes;
	    public int		 NumberOfParentNodes;
        public int       ActFunc;       // 0 - Sigmoid, 1 - Biplor Sigmoid, 2 - Tanh, 3 - Linear
	    public double[,] Weights;
	    public double[,] WeightChanges;
        public double [] NormalizeWt;
	    public double [] NeuronValues;
        public double [] ContextNeuronValues;
	    public double [] DesiredValues;
	    public double [] Errors;
	    public double [] BiasWeights;
	    public double [] BiasValues;
	    public double	 LearningRate;
        public double    MomentumFactor;
        public double    Alpha;
        public double    Beta;
        public bool      bipolarnorm;   // normalize to bipolar [-1,1] else default [0,1].
        public bool      rnn;

	    public NeuralNetworkLayer ParentLayer;
	    public NeuralNetworkLayer ChildLayer;

	    public NeuralNetworkLayer()
        {
            bipolarnorm     = false;
            rnn             = false;
            Alpha           = 2.0f;
            Beta            = 0.0f;
            ActFunc         = 0;
            LearningRate    = 0.3f;
            MomentumFactor  = 0.3f;
        }


        public void Initialize(int NumNodes, NeuralNetworkLayer parent, NeuralNetworkLayer child)
        {
	        int	i, j;

	        // Allocate memory
	        NeuronValues        = new double [NumberOfNodes];
	        DesiredValues       = new double [NumberOfNodes];
            ContextNeuronValues = new double [NumberOfNodes];
	        Errors              = new double [NumberOfNodes];

	        if(parent != null)
	        {		
		        ParentLayer = parent;
	        }

	        if(child != null)
	        {
		        ChildLayer = child;


                Weights = new double[NumberOfNodes, NumberOfChildNodes];
                WeightChanges = new double[NumberOfNodes, NumberOfChildNodes];

                BiasValues  = new double[NumberOfChildNodes];
                BiasWeights = new double[NumberOfChildNodes];
	        } else {
		        Weights = null;
		        BiasValues = null;
		        BiasWeights = null;
	        }

	        // Make sure everything contains zeros
	        for(i=0; i<NumberOfNodes; i++)
	        {
		        NeuronValues[i]         = 0;
		        DesiredValues[i]        = 0;
                ContextNeuronValues[i]  = 0;
		        Errors[i]               = 0;
        		
		        if(ChildLayer != null)
			        for(j=0; j<NumberOfChildNodes; j++)
			        {
				        Weights[i,j] = 0;
				        WeightChanges[i,j] = 0;
			        }
	        }

	        if(ChildLayer != null)
		        for(j=0; j<NumberOfChildNodes; j++)
		        {
			        BiasValues[j] = -1;
			        BiasWeights[j] = 0;
		        }

        }


        public void RandomizeWeights()
        {
	        int	i,j;
	        int	min = 0;
	        int	max = 200;
            int number;
	        Random randomNumber = new Random();

	        //srand( (unsigned)time( null ) );

	        for(i=0; i<NumberOfNodes; i++)
	        {
		        for(j=0; j<NumberOfChildNodes; j++)
		        {	
			        number = randomNumber.Next(min, max+1);    
     		        Weights[i,j] = (number / 100.0f - 1);
		        }
	        }
        	
	        for(j=0; j<NumberOfChildNodes; j++)
	        {
                number = randomNumber.Next(min, max + 1);  
                BiasWeights[j] = number / 100.0f - 1;
	        }
        }

        public void ZeroWeights()
        {
            int i, j;

            for (i = 0; i < NumberOfNodes; i++)
                for (j = 0; j < NumberOfChildNodes; j++)
                    Weights[i, j] = 0.0;

            for (j = 0; j < NumberOfChildNodes; j++)
                BiasWeights[j] = 1;
        }


        public void SetDirectSynapseWeights(double Beta)
        {
            int i, j;
            // Beta is a scaling constant between where 0 < Beta < 1;

            for (i = 0; i < NumberOfNodes; i++)
                for (j = 0; j < NumberOfChildNodes; j++)
                {
                    if (i == j)
                        Weights[i, j] = Beta;
                    else
                        Weights[i, j] = 0.0;
                }
        }

        
        public void SetFullSynapseWeights(double Beta)
        {
            int i, j;
            // Beta is a scaling constant between where 0 < Beta < 1;

            for (i = 0; i < NumberOfNodes; i++)
                for (j = 0; j < NumberOfChildNodes; j++)
                {
                    Weights[i, j] = Beta;
                }
        }


        public double BipolarSigmoidFunction(double u)
        {
            return ((2.0f / (1.0f + Math.Exp(-Alpha * u))) - 1.0f);
        }


        public double SigmoidFunction(double u)
        {
            return (1.0f / (1.0f + Math.Exp(-Alpha * u)));
        }


        public double TanhFunction(double u)
        {
            double e1 = Math.Exp(Alpha  * u);
            double e2 = Math.Exp(-Alpha * u);
            return ((e1-e2)/(e1+e2));

        }


        public double AlgebraicFunction(double u)
        {
            return (u / Math.Sqrt(1 + u * u));
        }


        public double BipolarTanhFunction(double u)
        {
            double e1 = Math.Exp(Alpha * u);
            double e2 = Math.Exp(-Alpha * u);
            return (-1.0f + 2 * (e1 - e2) / (e1 + e2));
        }


        public double SigmoidDerivative(double u)
        {
            return (Alpha * u * (1.0f - u));
        }


        public double TanhDerivative(double u)
        {
            return (Alpha * (1.0f - u * u));
        }


        public double AlgeDerivative(double u, double v)
        {
            return (Math.Pow(u, 3) / Math.Pow(v, 3));
        }


        public double Derivative(int ActFunc, double u)
        {
            double d = 0;

            switch (ActFunc)
            {
                case 0:
                    d = SigmoidDerivative(u);
                    break;

                case 1:
                    d = TanhDerivative(u);
                    break;

                case 2:
                    d = 1;
                    break;

                case 3:
                    d = 2* SigmoidDerivative(u);
                    break;

                default:
                    break;
            }

            return d;

        }


        public void CalculateErrors()
        {
	        int		i, j;
	        double	sum;
        	
	        if(ChildLayer == null) // output layer
	        {
		        for(i=0; i<NumberOfNodes; i++)
		        {
			        Errors[i] = (DesiredValues[i] - NeuronValues[i]) * Derivative(ActFunc, NeuronValues[i]);
		        }
	        } 
            else if(ParentLayer == null) { // input layer
		        for(i=0; i<NumberOfNodes; i++)
		        {
			        Errors[i] = 0.0f;
		        }
	        } else { // hidden layer
		        for(i=0; i<NumberOfNodes; i++)
		        {
			        sum = 0;
			        for(j=0; j<NumberOfChildNodes; j++)
			        {
				        sum += ChildLayer.Errors[j] * Weights[i,j];	
			        }
                    Errors[i] = sum * Derivative(ActFunc, NeuronValues[i]);
		        }
	        }
        }

        
        public void AdjustWeights()
        {
	        int		i, j;	
	        double	dw;

	        if(ChildLayer != null)
	        {
		        for(i=0; i<NumberOfNodes; i++)
		        {
			        for(j=0; j<NumberOfChildNodes; j++)
			        {
				        dw = LearningRate * ChildLayer.Errors[j] * NeuronValues[i];
				        Weights[i,j] += dw + MomentumFactor * WeightChanges[i,j];			
				        WeightChanges[i,j] = dw;
			        }
		        }

		        for(j=0; j<NumberOfChildNodes; j++)
		        {
			        BiasWeights[j] += LearningRate * ChildLayer.Errors[j] * BiasValues[j];
		        }
	        }
        }


        //Methods for Hidden nodes output for RNN. Uses Constant Weights!
        public void CalculateNeuronValues()
        {
            int i, j;
            double x;

            if (ParentLayer != null)
            {
                for (j = 0; j < NumberOfNodes; j++)
                {
                    x = 0;
                    for (i = 0; i < NumberOfParentNodes; i++)
                    {
                        x += ParentLayer.NeuronValues[i] * ParentLayer.Weights[i, j];
                    }
                    // constant scaled feedback from Context to Hidden Layer
                    if (rnn)
                        x += ContextNeuronValues[j] * Beta;

                    x += ParentLayer.BiasValues[j] * ParentLayer.BiasWeights[j];

                    switch(ActFunc)
                    {
                        case 0:
                            NeuronValues[j] = SigmoidFunction(x);
                            break;

                        case 1:
                            NeuronValues[j] = TanhFunction(x);
                            break;

                        case 2:
                            NeuronValues[j] = x;
                            break;

                        case 3:
                            NeuronValues[j] = BipolarSigmoidFunction(x);
                            break;

                        default:
                            break;
                    }

                    // save Hidden Node output to Context layer
                    if (rnn)
                        ContextNeuronValues[j] = NeuronValues[j];

                }
            }
        }
    };
}
