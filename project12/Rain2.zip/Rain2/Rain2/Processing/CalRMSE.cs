using System;
using System.Collections.Generic;
using System.Text;

namespace rain2
{
    public partial class Form1
    {
        public void computeRMSE(NeuralNetwork Brain, int node, int start, int end)
        {
            double mean, sum, value, sse, mse;
            mean = sum = value = sse = mse = 0;
            int col = 0;

            for (int i = start; i < end; i++)
                for (int j = 0; j < Brain.OutputLayer.NumberOfNodes; j++)
                {
                    col = j + outColStart - 1;
                    value = Normalize(inData[i, col], col);
                    sum += value;
                }

            mean = sum / (end - start) / Brain.OutputLayer.NumberOfNodes;

            // compute SSE, i.e. summation of (desired-predicted)^2
            for (int j = 0; j < Brain.OutputLayer.NumberOfNodes; j++)
                sse += Math.Pow((Brain.OutputLayer.DesiredValues[j] - Brain.OutputLayer.NeuronValues[j]), 2);

            mse = sse / (end - start) / Brain.OutputLayer.NumberOfNodes;
        }

    }
}
