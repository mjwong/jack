using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace rain2
{
    public partial class Form1
    {
        public void CalStats()
        {
            int col = 0;
            double predicted = 0.0f, desired = 0.0f;

            if (rmse != null)
                rmse = sum = mean = sse = ssw = rsq = null;

            rmse = new double[outNodes];
            sum  = new double[outNodes];
            mean = new double[outNodes];
            sse  = new double[outNodes];
            ssw  = new double[outNodes];
            rsq  = new double[outNodes];

            // initialize to zeros
            for (int j = 0; j < outNodes; j++)
                rmse[j] = sum[j] = mean[j] = sse[j] = ssw[j] = 0.0f;

            // compute the sums and summation of squares for the Test Set
            for (int i = 0; i < testCnt; i++)
                for (int j = 0; j < outNodes; j++)
                {
                    col = j + outColStart - 1;
                    // raw input and de-normalized neuron output
                    desired = DesiredTestOut[i, j];
                    predicted = PredictedTestOut[i, j];

                    sum[j] += desired;

                    // first compute summation of error^2
                    sse[j] += Math.Pow((desired - predicted), 2);
                }

            // compute output mean for the Test Set
            for (int j = 0; j < outNodes; j++)
                mean[j] = sum[j] / testCnt / outNodes;

            // compute SSW, i.e. summation of (desired-mean)^2
            for (int i = testSetStart; i < testSetEnd; i++)
                for (int j = 0; j < outNodes; j++)
                {
                    // normalize input
                    desired = Normalize(inData[i, col], col);
                    ssw[j] += Math.Pow((desired - mean[j]), 2);
                }

            // compute RMSE, i.e. sqrt of the mean
            // compute R-squared. Rsq = 1 - sse / ssw;
            for (int j = 0; j < outNodes; j++)
            {
                rmse[j] = Math.Sqrt(sse[j] / testCnt);
                rsq[j]  = 1 - sse[j] / ssw[j];
            }
        }
    }
}
