using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace rain2
{
    public partial class Form1
    {
        private void InitializeTestData()
        {
            TestNeuOut = null;
            DesiredTestOut = null;
            PredictedTrainOut = null;
            PredictedTestOut = null;
            PredictedTrainOut = new double[testSetStart, outNodes];
            TestNeuOut = new double[testCnt, outNodes];
            DesiredTestOut = new double[testCnt, outNodes];
            PredictedTestOut = new double[testCnt, outNodes];
            PredictedMinTestOut = new double[testCnt, outNodes];
            tsterr      = new double[testCnt];
            AcceptedSA  = new ArrayList();
            Temperature = new ArrayList();
            LearnRateSA = new ArrayList();
            MomentumSA  = new ArrayList();


            for (int i = 0; i < testCnt; i++)
            {
                tsterr[i] = 0.0f;
                for (int j = 0; i < outNodes; i++)
                {
                    DesiredTestOut[i, j] = PredictedTestOut[i, j] = 0.0f;
                    TestNeuOut[i, j] = 0.0f;
                }
            }
        }


        public void InitializeCoeff()
        {
            if ((TDLRadBtn.Checked || NARXBtn.Checked) && delta > 0)
            {
                coeffIn = new double[delta];
                for (int i = 0; i < delta; i++)
                    coeffIn[i] = 0.0f;

                InitMACoeff(coeffIn, delta, alphacoeff);
            }

            if (NARXBtn.Checked && epsilon > 0)
            {
                coeffOut = new double[epsilon];
                for (int i = 0; i < epsilon; i++)
                    coeffOut[i] = 0.0f;

                InitMACoeff(coeffOut, epsilon, alphacoeff);
            }
        }


        public void InitializeWeights(Weight Wt)
        {

        }
    }
}
