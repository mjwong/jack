using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace rain2
{
    public partial class Form1
    {
        public void CalMinMax()
        {
            double value = 0;

            for (int i = firstRec; i < readCnt; i++)
                for (int j = 0; j < attrCnt; j++)
                {
                    value = inData[i, j];
                    if (value < normWt[0, j])
                        normWt[0, j] = value;   // min
                    if (value > normWt[1, j])
                        normWt[1, j] = value;   // max

                    // compute normalized range, then multiply by scaling factor
                    normWt[2, j] = rangeSF * (normWt[1, j] - normWt[0, j]);
                    if ((readCnt == 0) || (normWt[2, j] == 9999))
                        MessageBox.Show("Data error - check first row whether Header is present.");
                }
        }


        public double Normalize(double x, int j)
        {
            if (bipolar)
                return 2 * x - (normWt[1, j] + normWt[0 ,j]) / normWt[2, j];
            else
                return (x - normWt[0, j]) / normWt[2, j];
        }


        public double DeNormalize(double x, int j)
        {
            if (bipolar)
                return (x * normWt[2, j] + (normWt[1, j] + normWt[0, j])) / 2;
            else
                return x * normWt[2, j] + normWt[0, j];
        }
    }
}
