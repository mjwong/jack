using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace rain2
{
    public partial class Form1
    {
        public static double WtMovAvg(double[] x, int n)
        {
            double wma = 0.0f;
            for (int i = 0; i < n; i++)
                wma += (n - i) * x[i];

            return wma /= n * (n + 1) / 2;
        }


        public double ExpMovAvg(double[] x, int n, double a)
        {
            double ema = 0.0f, denom = 1.0f, pow = 0.0f;
            for (int i = 0; i < n; i++)
            {
                pow = Math.Pow(1 - a, i);
                ema += pow * x[i];
                denom += pow;
            }
            return ema /= denom;
        }


        public void InitMACoeff(double[] x, int n, double a)
        {
            double denom = 0.0f;

            if (a > 0 && a < 1)
            {
                // Exponential MA
                for (int i = 0; i < n; i++)
                    denom += Math.Pow(1 - a, i);

                for (int i = 0; i < n; i++)
                    x[i] = Math.Pow(1 - a, i) / denom;
            }
            else
            {
                // Weighted MA
                denom = n * (n + 1) / 2;

                for (int i = 0; i < n; i++)
                    x[i] = (n - i) / denom;
            }
        }

    }
}
