using System;
using System.Collections.Generic;
using System.Text;

namespace rain2
{
    public partial class Form1
    {
        public void PreProcess()
        {
            // prepare data
            if (RandChkBox.Checked || IntvChkBox.Checked)
            {
                if (firstrun)
                    Randomize(readCnt);
                else
                {
                    Randomize(testSetStart);
                    firstrun = false;
                }
            }

            CalNumNodes();  // cal total no. of input nodes (inNodes) for TDL and NARX NN
            InitializeTestData();

            Wt     = new Weight(inNodes, hiddenNodes, hiddenNodes2, outNodes, fourlayer);
            CurrWt = new Weight(inNodes, hiddenNodes, hiddenNodes2, outNodes, fourlayer);
            MinWt  = new Weight(inNodes, hiddenNodes, hiddenNodes2, outNodes, fourlayer);
            InitializeCoeff();

            ArrY[0].Clear();
            ArrY[1].Clear();
            PlotWavelet();
        
        }

        
        public void CalNumNodes()
        {
            inNodes = inCol;

            // TDL NN: input time delay
            if (TDLRadBtn.Checked && delta > 0)
                inNodes += inCol * delta;           // add inCol * no. of delay line elements

            // NARX NN: input and output time delay
            if (NARXBtn.Checked)
            {
                if (delta > 0)
                    inNodes += inCol * delta;       // add inCol * no. of delay line elements

                if (epsilon > 0)
                    inNodes += outNodes * epsilon;  // inCol * no. of delay line elements
            }
        }
    }
}
