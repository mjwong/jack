using System;
using System.Collections.Generic;
using System.Text;

namespace rain2
{
    public partial class Form1
    {
        public void Randomize(int lastRec)
        {
            Random randomNumber = new Random();
            double[,] newrec = new double[lastRec, attrCnt];
            double temp;
            int number = 0, cnt = 0, factor = 1;
            int backcnt = lastRec;
            int lastnum = lastRec - 1;

            if (IntvChkBox.Checked)
            {
                number = randomNumber.Next(1, 10);
                //Console.WriteLine("\nInterleaving records... factor = {0}", number);
                for (int i = firstRec; i < backcnt; i++)
                {
                    if (cnt == number)
                    {
                        for (int j = 0; j < attrCnt; j++)
                        {
                            temp = inData[i, j];
                            inData[i, j] = inData[backcnt, j];
                            inData[backcnt, j] = temp;
                        }
                        cnt = 0;
                        backcnt--;
                    }
                    cnt++;
                }
            }

            if (RandChkBox.Checked)
            {
                if (lastnum > 65535)
                    factor = (int)(lastnum / 65535);

                for (int i = firstRec; i < lastRec; i++)
                {
                    if (lastnum > 65535)
                    {
                        number = randomNumber.Next(0, 65535);
                        number *= randomNumber.Next(0, factor);
                    }
                    else
                        number = randomNumber.Next(0, lastnum);
                    for (int j = 0; j < attrCnt; j++)
                    {
                        temp = inData[i, j];
                        inData[i, j] = inData[number, j];
                        inData[number, j] = temp;
                    }
                }
            }
        }
    }
}
