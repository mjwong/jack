using System;
using System.Collections.Generic;
using System.Text;

namespace rain2
{
    public partial class Form1
    {
        void SetTextEpochsBox(string text)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.EpochsBox.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetTextEpochsBox);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                // set current iteration's info
                EpochsBox.Text = text;
            }
        }


        void SetTextAvgTrainErrBox(string text)
        {
            try
            {
                if (this.AvgTrainErrBox.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextAvgTrainErrBox);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    AvgTrainErrBox.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }


        void SetTextAvgTestErrBox(string text)
        {
            try
            {
                if (this.AvgTestErrBox.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextAvgTestErrBox);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    AvgTestErrBox.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }


        void SetTextminErrBox(string text)
        {
            try
            {
                if (this.minErrBox.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextminErrBox);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    minErrBox.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }


        void SetTextTimeBox(string text)
        {
            try
            {
                if (this.TimeBox.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextTimeBox);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    TimeBox.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }


        void SetTextEpochSinceMinBox(string text)
        {
            try
            {
                if (this.EpochSMBox.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextEpochSinceMinBox);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    EpochSMBox.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }


        void SetTextRMSE1Box(string text)
        {
            try
            {
                if (this.RMSE1Box.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextRMSE1Box);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    RMSE1Box.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }


        void SetTextRMSE2Box(string text)
        {
            try
            {
                if (this.RMSE2Box.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextRMSE2Box);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    RMSE2Box.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }


        void SetTextEpochMinRMSEBox(string text)
        {
            try
            {
                if (this.EpochMinRMSEBox.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextEpochMinRMSEBox);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    EpochMinRMSEBox.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }


        void SetTextRSQ1Box(string text)
        {
            try
            {
                if (this.RSq1Box.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextRSQ1Box);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    RSq1Box.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }


        void SetTextRSQ2Box(string text)
        {
            try
            {
                if (this.RSq2Box.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextRSQ2Box);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    RSq2Box.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }


        void SetTextTrnOKBox(string text)
        {
            try
            {
                if (this.trnOKBox.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextTrnOKBox);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    trnOKBox.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }


        void SetTextTrnNOKBox(string text)
        {
            try
            {
                if (this.trnNOKBox.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextTrnNOKBox);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    trnNOKBox.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }


        void SetTextTestOKBox(string text)
        {
            try
            {
                if (this.testOKBox.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextTestOKBox);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    testOKBox.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }


        void SetTextTestNOKBox(string text)
        {
            try
            {
                if (this.testNOKBox.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextTestNOKBox);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    testNOKBox.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }


        void SetTextSMAPEBox(string text)
        {
            try
            {
                if (this.SmapeBox.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextSMAPEBox);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    SmapeBox.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }


        void SetTextCurrLrnRateBox(string text)
        {
            try
            {
                if (this.CLrnRateBox.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextCurrLrnRateBox);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    CLrnRateBox.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }


        void SetTextCurrMomentumBox(string text)
        {
            try
            {
                if (this.CMomentumBox.InvokeRequired)
                {
                    SetTextCallback d = new SetTextCallback(SetTextCurrMomentumBox);
                    this.Invoke(d, new object[] { text });
                }
                else
                {
                    CMomentumBox.Text = text;
                }
            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("Caught: {0}", e.Message);
            }
        }
    }
}
