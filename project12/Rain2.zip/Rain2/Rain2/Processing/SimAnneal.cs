﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace rain2
{
    public partial class Form1
    {
        /*
            Simulated Annealing
            1.  Set the independent variables to their expected values - 
                this is used as the initial centering point. 
            2.  Set the temperature to a relatively high number. 
            3.  Perturb the independent variables. 
            4.  Calculate the new result (or error with an NN) with the new variables. 
            5.  If the new result is lower than the best, save the result. 
            6.  Repeat steps 3-5 n number of times. 
            7.  If an improvement has been made after the n number of iterations, set the centre point to be the best point. 
            8.  Reduce the temperature. 
            9.  Repeat steps 3-8 for t number of temperatures. 
            
            c = exp((ln(stop/start)/(t-1))

            Stop and start are the stop and start temperatures, 
            and t is the number of intermediate temperatures.
         */

        public void SimAnneal(double workEnergy)
        {
            Boolean useNew = false;
            double test = 0, delta = 0, calc = 0;

            if (currTemp > finalTemp)
            {
                int T = Convert.ToInt32(currTemp);
                workMomentum = (Convert.ToDouble(randomNumber.Next(finalTemp, T))) / startTemp;
                workLrnRate  = (Convert.ToDouble(randomNumber.Next(finalTemp, T))) / startTemp;
                MomentumSA.Add(workMomentum*100);
                LearnRateSA.Add(workLrnRate*100);

                if (workEnergy <= currEnergy)
                {
                    useNew = true;
                }
                else
                {
                    test = Convert.ToDouble(randomNumber.Next(1, 1000)) / 1000;
                    delta = workEnergy - currEnergy;
                    calc = Math.Exp(-delta/currTemp);

                    if (calc > test)
                    {
                        accepted++;
                        useNew = true;
                    }
                }

                if (useNew)
                {
                    useNew = false;
                    currMomentum = workMomentum;    // copy from working to current
                    currLrnRate  = workLrnRate;
                    currEnergy   = workEnergy;

                    if (currEnergy < bestEnergy)
                    {
                        bestMomentum = currMomentum;    // copy from current to best
                        bestLrnRate  = currLrnRate;
                        bestEnergy   = currEnergy;
                    }
                    else
                    {
                        workMomentum = currMomentum;    // copy from current to working
                        workLrnRate  = currLrnRate;
                        workEnergy   = currEnergy;
                    }

                }

                Temperature.Add(currTemp);
                AcceptedSA.Add(accepted);

                if (currStep++ == stepsPerChg)
                {
                    currTemp *= alphaTemp;
                    currStep = accepted = 0;
                }

            }
        }
    }
}
