using System;
using System.Collections.Generic;
using System.Text;

namespace rain2
{
    public partial class Form1
    {
        public void TestTheBrain()
        {
            double err = 0, avgerr = 0, abserr = 0, neuout = 0, avg = 0;
            int col = 0, count = 0;
            currTestErr = smape = 0;

            // iterate over the Test Set
            for (int i = testSetStart; i < testSetEnd; i++)
            {
                avgerr += tsterr[count] = err = FeedFwd(TheBrain, i);

                if (err < errThresh) testErrOK++; else testErrNOK++;

                for (int j = 0; j < outNodes; j++)
                {
                    col = j + outColStart - 1;

                    // de-normalized neuron output for predicted values
                    // save testSetEnd output. TestNeuOut is in normalized form.
                    neuout                      = TheBrain.GetOutput(j);
                    TestNeuOut[count, j]        = neuout;
                    DesiredTestOut[count, j]    = inData[i, col];   //desired
                    PredictedTestOut[count, j]  = DeNormalize(neuout, col);

                    abserr = Math.Abs(DesiredTestOut[count, j] - PredictedTestOut[count, j]);
                    avg    = DesiredTestOut[count, j] + PredictedTestOut[count, j];
                    smape += (abserr / avg);
                }
                count++;    // test record no.
            }

            smape = smape * 200 / testCnt / outNodes;

            CalStats();

            lock (ArrY[1])
            {
                currTestErr = avgerr /= testCnt;    // avg. test error;
                ArrY[1].Add(avgerr * 100);          // update chart data pt
            }

            epochAftMinRMSE++;

            if (rmse[0] < minTestRMSE)
            {
                minTestRMSE = rmse[0];
                epochAftMinRMSE = 0;
                lock (MinBrain)
                {
                    MinBrain = (NeuralNetwork)TheBrain.Clone();
                    saveWeights(MinBrain, MinWt);   // save Wts for min. RMSE
                    TestMinBrain();                 // Set Min Wts to new TheBrain & cal predicted values
                }
            }

            // update display
            if (!pagechange)
            {
                SetTextAvgTestErrBox(Math.Round(avgerr, 6).ToString()); 
                SetTextEpochMinRMSEBox(epochAftMinRMSE.ToString());
                SetTextTestOKBox(testErrOK.ToString());
                SetTextTestNOKBox(testErrNOK.ToString());
                SetTextSMAPEBox(Math.Round(smape, 6).ToString());
                SetTextRMSE1Box(Math.Round(rmse[0], 6).ToString());
                SetTextRSQ1Box(Math.Round(rsq[0], 6).ToString());
                if (outNodes > 1)
                {
                    SetTextRMSE2Box(Math.Round(rmse[1], 6).ToString());
                    SetTextRSQ2Box(Math.Round(rsq[1], 6).ToString());
                }
            }
         }
    }
}
