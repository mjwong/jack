using System;
using System.Collections.Generic;
using System.Text;

namespace rain2
{
    public partial class Form1
    {
        private void setWeights(NeuralNetwork Brain, Weight Weights)
        {
            int i, j;

            // Input - to - Hidden layer weights
            for (i = 0; i < inNodes; i++)
                for (j = 0; j < hiddenNodes; j++)
                    Brain.InputLayer.Weights[i, j] = Weights.In[i, j];

            for (j = 0; j < hiddenNodes; j++)
                Brain.InputLayer.BiasWeights[j] = Weights.BiasIn[j];

            if (fourlayer)
            {
                // Hidden - to - Hidden2 layer weights
                for (i = 0; i < hiddenNodes; i++)
                    for (j = 0; j < hiddenNodes2; j++)
                        Brain.HiddenLayer.Weights[i, j] = Weights.Hid[i, j];

                for (j = 0; j < hiddenNodes2; j++)
                    Brain.HiddenLayer.BiasWeights[j] = Weights.BiasHid[j];

                // Hidden2 - to - Output layer weights
                for (i = 0; i < hiddenNodes2; i++)
                    for (j = 0; j < outNodes; j++)
                        Brain.HiddenLayer2.Weights[i, j] = Weights.Out[i, j];

                for (j = 0; j < outNodes; j++)
                    Brain.HiddenLayer2.BiasWeights[j] = Weights.BiasOut[j];
            }
            else
            {
                // Hidden - to - Output layer weights
                for (i = 0; i < hiddenNodes; i++)
                    for (j = 0; j < outNodes; j++)
                        Brain.HiddenLayer.Weights[i, j] = Weights.Out[i, j];

                for (j = 0; j < outNodes; j++)
                    Brain.HiddenLayer.BiasWeights[j] = Weights.BiasOut[j];
            }
        }


        public void TestMinBrain()
        {
            int col = 0;
            minfound = true;

            // set the min. wts to the Brain
            //setWeights(Brain, MinWt);

            // iterate over the Test Set
            for (int i = 0; i < testCnt; i++)
            {
                FeedFwd(MinBrain, i);

                for (int j = 0; j < outNodes; j++)
                {
                    col = j + outColStart - 1;

                    // de-normalized neuron output for predicted values
                    PredictedMinTestOut[i, j] = DeNormalize(MinBrain.GetOutput(j), col);
                }
            }
        }
    }
}
