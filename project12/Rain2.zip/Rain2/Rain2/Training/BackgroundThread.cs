using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text;
using System.Collections;

namespace rain2
{
    public partial class Form1
    {
        public void SearchSoln()
        {
            NeuralNetwork Brain = new NeuralNetwork();
            
            // store original no. of input nodes
            Brain.inDataNodes = inCol;
            Brain.Initialize(inNodes, hiddenNodes, hiddenNodes2, outNodes, fourlayer);
            Brain.SetLearningRate(learningRate);
            Brain.SetMomentum(momentum);
            Brain.SetActiveFunct(hidActF, hid2ActF, outActF);
            Brain.SetAlpha(Alpha);

            if (RNNRadBtn.Checked)
                Brain.SetBeta(Beta);
            else
                Brain.SetBeta(0);

            TrainBrain(Brain);
            Brain = null;
        }
    }
}
