using System;
using System.Collections.Generic;
using System.Text;

namespace rain2
{
    public partial class Form1
    {

        private void InitDelayElements(NeuralNetwork Brain)
        {
            // clear initial tapped input delay line values
            if (TDLRadBtn.Checked && delta > 0)
                Brain.ClearInputDelay(delta);

            // NARX: both input and output tapped delay line values
            if (NARXBtn.Checked)
            {
                if (delta > 0)
                    Brain.ClearInputDelay(delta);

                if (epsilon > 0)
                    Brain.ClearOutputDelay(epsilon);
            }
        }


        private void ShiftDelayElements(NeuralNetwork Brain)
        {
            // tapped input delay line
            if (TDLRadBtn.Checked && delta > 0)
            {
                if (WMARadBtn.Checked || EMARadBtn.Checked)
                    Brain.ApplyMACoeffToInput(coeffIn, delta);

                Brain.ShiftInput(delta);
            }

            // NARX: both input and output tapped delay line
            if (NARXBtn.Checked)
            {
                if (delta > 0)
                {
                    if (WMARadBtn.Checked || EMARadBtn.Checked)
                        Brain.ApplyMACoeffToInput(coeffIn, delta);

                    Brain.ShiftInput(delta);
                }

                if (epsilon > 0)
                {
                    if (WMARadBtn.Checked || EMARadBtn.Checked)
                        Brain.ApplyMACoeffToInput(coeffOut, epsilon);

                    Brain.ShiftOutput(epsilon);
                }
            }
        }


        private void ApplyMADelayElements(NeuralNetwork Brain)
        {
            // tapped input delay line
            if (TDLRadBtn.Checked && delta > 0)
            {

            }

            // NARX: both input and output tapped delay line
            if (NARXBtn.Checked)
            {
                if (delta > 0)
                    Brain.ShiftInput(delta);

                if (epsilon > 0)
                    Brain.ShiftOutput(epsilon);
            }
        }
    }
}
