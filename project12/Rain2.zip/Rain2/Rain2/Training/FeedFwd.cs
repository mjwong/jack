using System;
using System.Collections.Generic;
using System.Text;

namespace rain2
{
    public partial class Form1
    {
        private double FeedFwd(NeuralNetwork Brain, int i)
        {
            int col = 0;
            for (int j = 0; j < inCol; j++)
            {
                // normalize input values
                Brain.SetInput(j, Normalize(inData[i, j], j));
            }

            for (int j = 0; j < outNodes; j++)
            {
                col = j + outColStart - 1;

                // normalize desired output values
                Brain.SetDesiredOutput(j, Normalize(inData[i, col], col));
            }

            Brain.FeedForward(fourlayer);

            return Brain.CalculateError();
        }
    }
}
