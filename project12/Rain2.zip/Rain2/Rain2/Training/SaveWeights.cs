using System;
using System.Collections.Generic;
using System.Text;

namespace rain2
{
    public partial class Form1
    {
        private void saveWeights(NeuralNetwork Brain, Weight Weights)
        {
            int i, j;

            // Input - to - Hidden layer weights
            for (i = 0; i < inNodes; i++)
                for (j = 0; j < hiddenNodes; j++)
                {
                    Weights.In[i, j] = Brain.InputLayer.Weights[i, j];
                    Weights.ArrWtIntoHid[i, j].Add(Weights.In[i, j]);
                }

            for (j = 0; j < hiddenNodes; j++)
                Weights.BiasIn[j] = Brain.InputLayer.BiasWeights[j];

            if (fourlayer)
            {
                // Hidden - to - Hidden2 layer weights
                for (i = 0; i < hiddenNodes; i++)
                    for (j = 0; j < hiddenNodes2; j++)
                    {
                        Weights.Hid[i, j] = Brain.HiddenLayer.Weights[i, j];
                        Weights.ArrWtHidtoHid2[i,j].Add(Weights.Hid[i, j]);
                    }
                for (j = 0; j < hiddenNodes2; j++)
                    Weights.BiasHid[j] = Brain.HiddenLayer.BiasWeights[j];

                // Hidden2 - to - Output layer weights
                for (i = 0; i < hiddenNodes2; i++)
                    for (j = 0; j < outNodes; j++)
                    {
                        Weights.Out[i, j] = Brain.HiddenLayer2.Weights[i, j];
                        Weights.ArrWtHidtoOut[i,j].Add(Weights.Out[i, j]);
                    }
                for (j = 0; j < outNodes; j++)
                    Weights.BiasOut[j] = Brain.HiddenLayer2.BiasWeights[j];
            }
            else
            {
                // Hidden - to - Output layer weights
                for (i = 0; i < hiddenNodes; i++)
                    for (j = 0; j < outNodes; j++)
                    {
                        Weights.Out[i, j] = Brain.HiddenLayer.Weights[i, j];
                        Weights.ArrWtHidtoOut[i,j].Add(Weights.Out[i, j]);
                    }

                for (j = 0; j < outNodes; j++)
                    Weights.BiasOut[j] = Brain.HiddenLayer.BiasWeights[j];
            }
        }
    }
}
