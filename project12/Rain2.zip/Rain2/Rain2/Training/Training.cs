using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Threading;

namespace rain2
{
    public partial class Form1
    {
        public void TrainBrain(NeuralNetwork Brain)
        {
            int i, col, c, epochAfterMin;
            double error = 1;
            string showtime     = null;
            Stopwatch stopWatch = new Stopwatch();
            TimeSpan ts         = new TimeSpan();
            Thread testThread   = null;
            
            // initialize local & global variables
            i = col = c = epochAfterMin = 0;
            trnErrOK = trnErrNOK = testErrOK = testErrNOK = 0;

            stopWatch.Start();
            ts = stopWatch.Elapsed;

            Brain.DumpData(outDir, "PreTraining.txt");

            if (sanneal)
            {
                // simulated annealing variables
                currTemp = startTemp;
                workLrnRate = currLrnRate = learningRate;
                workMomentum = currMomentum = momentum;
                workEnergy = currEnergy = minErr = 999;
            }

            while ((error > errLimit) && (c < iterations) &&
                (epochAfterMin < epochFrMin) && (epochAftMinRMSE < epochFrMinRMSE)
                && !needtostop)
            {
                error = 0;
                currEpoch = ++c;
                epochAfterMin++;

                InitDelayElements(Brain);

                for (i = trainSetStart; i < testSetStart; i++)
                {
                    error += FeedFwd(Brain, i);

                    Brain.BackPropagate(fourlayer);

                    // get Training output values
                    for (int j = 0; j < outNodes; j++)
                    {
                        col = j + outColStart - 1;
                        PredictedTrainOut[i, j] = DeNormalize(Brain.GetOutput(j), col);
                    }

                    ShiftDelayElements(Brain);

                    if (error < errThresh) trnErrOK++; else trnErrNOK++;

                }

                saveWeights(Brain, CurrWt);
                
                lock (ArrY[0])
                {
                    currTrnErr = error /= trainCnt;	    // divide by no. of training rec
                    ArrY[0].Add(error * 100);           // update chart data pt
                }

                if (error < minErr)
                {
                    minErr = error;
                    epochAfterMin = 0;
                }

                if (MTChkBox.Checked && testThread != null)
                    if (testThread.ThreadState.Equals(System.Threading.ThreadState.Running))
                        testThread.Join();

                lock (TheBrain)
                {
                    TheBrain = (NeuralNetwork)Brain.Clone();   // clone the NN before calling TestBrain

                    if (MTChkBox.Checked)
                    {
                        testThread = new Thread(new ThreadStart(TestTheBrain));
                        testThread.Name = "TestThread " + c.ToString();
                        testThread.Start();
                    }
                    else
                        TestTheBrain(); //test set inputs
                }

                // update display
                if (!pagechange)
                {
                    SetTextAvgTrainErrBox(Math.Round(error, 6).ToString());
                    SetTextEpochsBox(c.ToString());
                    SetTextminErrBox(Math.Round(minErr, 6).ToString());
                    ts = stopWatch.Elapsed;
                    showtime = String.Format("{0:00}:{1:00}", ts.Minutes, ts.Seconds);
                    SetTextTimeBox(showtime);
                    SetTextEpochSinceMinBox(epochAfterMin.ToString());
                    SetTextTrnOKBox(trnErrOK.ToString());
                    SetTextTrnNOKBox(trnErrNOK.ToString());
                }
            
                // simulated annealing
                if (sanneal)
                {
                    SimAnneal(error);
                    Brain.SetLearningRate(currLrnRate);
                    Brain.SetMomentum(currMomentum);
                    SetTextCurrLrnRateBox(Math.Round(currLrnRate, 3).ToString());
                    SetTextCurrMomentumBox(Math.Round(currMomentum, 3).ToString());
                }
            
            }

            stopWatch.Stop();
            saveWeights(Brain, Wt);
            Brain.DumpData(outDir, "PostTraining.txt");
        }
    }
}
