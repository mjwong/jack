using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Text;
using System.IO;

namespace rain2
{
    public partial class Form1
    {
        public void InitR()
        {
            inData  = new double[maxRec, attrCnt];
            normWt  = new double[3, attrCnt];
            colName = new string[attrCnt+1];

            for (int i = 0; i < maxRec; i++)
                for (int j = 0; j < attrCnt; j++)
                    inData[i, j] = 0;

            for (int i = 0; i < attrCnt; i++)
            {
                normWt[0, i] = 9999;  //min
                normWt[1, i] = -9999; //max
                normWt[2, i] = 9999;  //range
            }
        }


        private string CleanInput(string strIn)
        {
            // Replace invalid characters with empty strings.
            return Regex.Replace(strIn, "[\"]", "");
        }


        public void readFile(String infile)
        {
            String line = null;
            String[] split;
            StreamReader MyStreamReader = null;

            try
            {
                MyStreamReader = new StreamReader(infile);
            }
            catch (FileLoadException e)
            {
                Console.WriteLine("Exception: Failed to load file: {0}. {1}", infile, e);                
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: Failed to create a stream reader with error:");
                Console.WriteLine("Source : " + e.Source);
                Console.WriteLine("Message : " + e.Message);
            }

            try
            {
                // read first row
                readCnt = 0;
                if (MyStreamReader.Peek() >= 0)
                {
                    line = MyStreamReader.ReadLine();
                    split = line.Split(',');
                    attrCnt = split.Length;
                    InitR();

                    if (ColNamesBox.Checked)
                        firstRec = 1;
                    else
                        firstRec = 0;

                    colName[0] = "No.";
                    for (int i = 0; i < attrCnt; i++)
                    {
                        if (firstRec > 0)
                            colName[i+1] = CleanInput(split[i]);
                        else
                        {
                            colName[i+1] = "Col" + Convert.ToString(i + 1);
                            inData[readCnt, i] = Convert.ToDouble(split[i]);
                        }
                    }
                    readCnt++;
                }
                
                while (MyStreamReader.Peek() >= 0)
                {
                    line = MyStreamReader.ReadLine();
                    split = line.Split(',');
                    for (int i = 0; i < attrCnt; i++)
                        inData[readCnt, i] = Convert.ToDouble(split[i]);
                    readCnt++;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("readFile module.\n");
                Console.WriteLine("Exception: Failed to read using a stream reader with error.");
                Console.WriteLine("Source   : " + e.Source);
                Console.WriteLine("Message  : " + e.Message);
            }
            finally
            {
                if (MyStreamReader == null)
                    fileerror = true;
                else
                {
                    MyStreamReader.Close();
                    MyStreamReader = null;
                }
            }
        }
    }
}
